"""Complete two roof station interfaces and actual bank load paths.

Case/foam and nominal jacket fit remain delivery gates. Four full9mm lands
have a separate common split clamp;4905 never substitutes for strain relief.
Selected T18I head is4.3x5.3x5, no6mm fictitious cube. No purchased parts cut.
"""
CaseTick=time.monotonic();Case29={};CaseOwn=[];CaseRows=[];CaseChecks=0;CaseRoots={};CaseContracts=[]
CaseTf={
 'D_RL':(A.Rotation(A.Vector(0,0,1),180).multiply(A.Rotation(A.Vector(1,0,0),-90)),A.Vector(86,-65.6,18),A.Vector(15,-27,88.75),-1),
 'RL_G':(A.Rotation(A.Vector(1,0,0),-90),A.Vector(46,65.6,18),A.Vector(75,27,88.75),1)}
def case_place(s,g):
 rot,old,new,side=CaseTf[g];s=retention.isolated(s);s.Placement=A.Placement(new-rot.multVec(old),rot)*s.Placement;return s
def fuse_parts(parts):
 result=retention.isolated(parts[0]).multiFuse([retention.isolated(s) for s in parts[1:]]);result.check(True)
 assert result.isValid() and len(result.Solids)==1
 return result
for group,(rot,old,c,side) in CaseTf.items():
 Case29[group+':case']=case_place(material['Station:'+group+':case'],group)
 Case29[group+':4905_pad']=pbox([c.x-6,c.y-6,83.75],[c.x+6,c.y+6,84.25])
 floor=pbox([c.x-15.5,-37.5 if side<0 else 8,81.25],[c.x+15.5,-8 if side<0 else 37.5,83.75])
 roots=[floor]
 # One wider-depth pedestal in the REAL gap between adjacent full terminals.
 # The two former post locations crossed IN/OUT metal. Slot centre derives
 # from both purchased terminal bounds, not a sequence of wire offsets.
 if group=='D_RL':
  left=material['Ref_Material_F_R3_CP2_OUT_0_0'].BoundBox.XMax
  right=material['Ref_Material_F_R3_CP2_IN_0_0'].BoundBox.XMin
 else:
  left=material['Ref_Material_F_L6_CP2_IN_0_0'].BoundBox.XMax
  right=material['Ref_Material_F_L6_CP2_OUT_0_0'].BoundBox.XMin
 assert right-left>=5.5
 x=(left+right)/2-1.5
 housing=material['Ref_Material_F_R3_CP2_Housing_0_0' if group=='D_RL' else 'Ref_Material_F_L6_CP2_Housing_0_0']
 foot_top=housing.BoundBox.ZMin-1.25
 yy=sorted((side*30,side*37.95));roots.append(pbox([x,yy[0],foot_top-.25],[x+3,yy[1],83.75]))
 yy=sorted((side*30,side*42));roots.append(pbox([x,yy[0],foot_top-2],[x+3,yy[1],foot_top]))
 ends=[e for e in EndContract['endpoints'] if e.get('endpoint') in {'D_RL':['D_RL.2','D_RL.3','D_RL.4','D_RL.5'],'RL_G':['RL_G.1','RL_G.2','RL_G.3','RL_G.4']}[group]]
 assert len(ends)==4
 mouths=[]
 for e in ends:
  q=rot.multVec(A.Vector(*e['point_mm'])-old)+c;d=rot.multVec(A.Vector(*e['departure_axis']));a=q+9*d
  mouths.append((e,q,d,a));CaseContracts.append(dict(end_id=e['id'],mouth=list(q),departure=list(d),jacket_land9=[list(q),list(a)],nominal_jacket_radius_mm=1.55,supplier_OD_or_datum_guaranteed=False))
 xs=[q.x for _,q,_,_ in mouths];ys=sorted([mouths[0][1].y,mouths[0][3].y]);xmin,xmax=min(xs)-3.55,max(xs)+3.55
 bed=pbox([xmin,ys[0],85.2],[xmax,ys[1],88.75]);cap=pbox([xmin,ys[0],88.75],[xmax,ys[1],92.3]);holes=[]
 for e,q,d,a in mouths:holes.append(Part.makeCylinder(1.55,9.2,q-.1*d,d))
 cutters=Part.makeCompound(holes);bed=bed.cut(cutters);cap=cap.cut(cutters);bed.check(True);cap.check(True)
 assert bed.isValid() and cap.isValid() and len(bed.Solids)==len(cap.Solids)==1
 roots.append(bed)
 web_ys=[ys[0],ys[1]-2] if group=='RL_G' else [ys[0],ys[1]-.25]
 for y in web_ys:roots.append(pbox([xmin,y,83.5],[xmax,y+2,85.4]))
 carrier=fuse_parts(roots);Case29[group+':carrier']=carrier;Case29[group+':cap']=cap
 bank=retention.isolated(material['CurrentFoundation:BankBedCurrent:'+str(side)])
 pad_name='CurrentFoundation:BankPad:Ref_Material_'+('F_R3' if group=='D_RL' else 'F_L6')+'_CP2_Housing_0_0:0'
 owned_names=['CurrentFoundation:BankBedCurrent:'+str(side),pad_name]
 owned=[bank,material[pad_name]]
 if group=='RL_G':
  owned_names.extend(['CurrentFoundation:BankLedge:4','CurrentFoundation:BankPier:4'])
  owned.extend([material[n] for n in owned_names[2:]])
 owned_union=fuse_parts(owned)
 joint=retention.isolated(carrier).common(bank);whole=fuse_parts([carrier]+owned);CaseRoots[group]=whole
 assert joint.Volume>0,(group,joint.Volume)
 CaseOwn.append(dict(group=group,actual_bank_joint_mm3=joint.Volume,carrier_one_BOP_solid=True,carrier_plus_current_bank_one_BOP_solid=True,
                     envelope_mm=[carrier.BoundBox.XLength,carrier.BoundBox.YLength,carrier.BoundBox.ZLength]))
 mid=sum(ys)/2+(2 if group=='D_RL' else 0);lo,hi=mid-1.25,mid+1.25
 strips=[pbox([xmin-1.2,lo,84.0],[xmin,hi,93.5]),pbox([xmax,lo,84.0],[xmax+1.2,hi,93.5]),
         pbox([xmin,lo,84.0],[xmax,hi,85.2]),pbox([xmin,lo,92.3],[xmax,hi,93.5])]
 Case29[group+':T18I_band']=Part.makeCompound(strips)
 headlo=xmax+1.2 if group=='D_RL' else xmin-1.2-4.3
 Case29[group+':T18I_head']=pbox([headlo,mid-2.5,86.1],[headlo+4.3,mid+2.5,91.4])
 # Existing bank surface/contact isn't a newly introduced interface.
 checked_carrier=retention.isolated(carrier).cut(owned_union)
 for suffix in ['case','carrier','cap','T18I_band','T18I_head']:
  s=checked_carrier if suffix=='carrier' else Case29[group+':'+suffix]
  for n,b in NineFixed.items():
   if n.startswith(('Station:D_RL:','Station:RL_G:','D_RL:','RL_G:')) or n in owned_names:continue
   if bbox_lower_bound(s.BoundBox,b.BoundBox)>1.25:continue
   gap=distance(s,b);CaseChecks+=1
   if gap<1.25-1e-6:CaseRows.append(dict(part=group+':'+suffix,other=n,gap_mm=gap,intersection_mm3=retention.isolated(s).common(retention.isolated(b)).Volume if gap<1e-6 else 0))
CaseReceipt=dict(scope=__doc__,roots=CaseOwn,ends=CaseContracts,foreign_checks=CaseChecks,rows=CaseRows,seconds=time.monotonic()-CaseTick,
                 maximum_new_print_side_mm=max(max(r['envelope_mm']) for r in CaseOwn),nominal_case_and_cable_fit_phase2=True,full_stock_assembly_motion_and_tools_pending=True,N01_complete=False,physical_pass=False)
(OUT/'day29-roof-case-carriers-receipt.json').write_text(json.dumps(CaseReceipt,indent=2)+'\n')
print('ROOF_CASE_CARRIERS',json.dumps(CaseReceipt),flush=True)

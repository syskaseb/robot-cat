"""Move printed U1 load path inboard BEFORE routing another wire around it.

Source: plan_feline_u1_common_carrier.construct and current actual BRep.
Keep entire selected clamp/fasteners,46.6beam tier and U1Relief:ForeRoot.
Replace the overhung Y91.2..95.2 return by a direct post at the existing
beam/front-root side, beyond the three unchanged band ends X25.647.
No bought part or PCB is cut and no pad becomes a mechanical mounting hole.
"""
U1Tick=time.monotonic();oldU1=retention.isolated(material['U1Carrier:Fore:Base']);oldU1.check(True)
newPost=pbox([27,84,-14.84],[31,88,50.6]);newCap=pbox([24,84,46.6],[31,88,50.6])
trim=pbox([0,88,-50],[200,120,120])
cut=oldU1.cut(trim);newU1=cut.multiFuse([newPost,newCap]);newU1.check(True)
assert newU1.isValid() and len(newU1.Solids)==1
rootU1=retention.isolated(material['U1Relief:ForeRoot']);jointU1=newU1.common(rootU1)
wholeU1=retention.isolated(newU1).fuse(rootU1);wholeU1.check(True)
assert jointU1.Volume>0 and wholeU1.isValid() and len(wholeU1.Solids)==1
U1Added=retention.isolated(newU1).cut(retention.isolated(oldU1));U1Rows=[];U1Checks=0
for name,s in [('post',newPost),('cap',newCap)]:
 for n,b in occupied.items():
  if n in ['U1Carrier:Fore:Base','U1Relief:ForeRoot']:continue
  if bbox_lower_bound(s.BoundBox,b.BoundBox)>1.25:continue
  gap=distance(s,b);U1Checks+=1
  if gap<1.25-1e-6:U1Rows.append(dict(part=name,other=n,gap_mm=gap,intersection_mm3=retention.isolated(s).common(retention.isolated(b)).Volume if gap<1e-6 else 0))
 for a in actorsMotion:
  if bbox_lower_bound(s.BoundBox,A.BoundBox(*a['bounds'][0],*a['bounds'][1]))>1.25:continue
  local=s.copy();local.Placement=placement(a['r'],a['t']).inverse()*local.Placement;b=InvalidCovers[a['name']] if a['name'] in badrest else restMotion[a['name']];gap=distance(local,b);U1Checks+=1
  if gap<1.25-1e-6:U1Rows.append(dict(part=name,other=a['name'],pose=a['pose'],gap_mm=gap,invalid_cover_not_contact=a['name'] in badrest))
U1Receipt=dict(scope=__doc__,source_native_sha256=CP['native']['sha256'],source_actor='U1Carrier:Fore:Base',
 current_frame_clamp_and_hardware_preserved=True,current_U1_ForeRoot_preserved=True,old_joint_mm3=oldU1.common(rootU1).Volume,new_joint_mm3=jointU1.Volume,
 new_base_one_BOP_solid=True,new_base_plus_root_one_BOP_solid=True,added_mm3=U1Added.Volume,removed_mm3=oldU1.cut(newU1).Volume,
 foreign_checks=U1Checks,rows=U1Rows,seconds=time.monotonic()-U1Tick,N01_complete=False,physical_pass=False)
(OUT/'day29-direct-U1-carrier-receipt.json').write_text(json.dumps(U1Receipt,indent=2)+'\n')
print('DIRECT_U1',json.dumps(U1Receipt),flush=True)

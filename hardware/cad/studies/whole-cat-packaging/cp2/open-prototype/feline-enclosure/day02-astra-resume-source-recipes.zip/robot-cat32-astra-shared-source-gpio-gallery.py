tick=time.perf_counter();cpu=time.process_time()
p=OUT/'day02-astra-shared-SOURCE-GPIO-gallery-c0-proposal.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='2729eee1f7b72f19a0c139da58b95a2e7c5648e085b8779f1a32f4f2e715ab8c'
SharedSourceGPIO32=Part.makeBox(24,10,10,A.Vector(31,4,80));SharedSourceGPIO32.check(True);assert SharedSourceGPIO32.isValid()
raw=SharedSourceGPIO32.exportBrepToString().encode();arc=OUT/'day02-astra-shared-SOURCE-GPIO-gallery-c0.breps.zip';assert not arc.exists();g=[{'name':'SOURCE_GPIO:full4core_shared_gallery_capacity','entry':'0.brep','sha256':hashlib.sha256(raw).hexdigest()}]
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('0.brep',raw);z.writestr('manifest.json',json.dumps({'geometry':g}))
rows=[];members=[]
for n,s in CurrentC1Selected32.items():
 if bbox_lower_bound(SharedSourceGPIO32.BoundBox,s.BoundBox)>=1.25:continue
 if n in ['Underdeck:SOURCE:XP02.source','Underdeck:SOURCE:XP03.source']:
  members.append({'name':n,'role':'Only flexible freeportion inside declaredgallery; external trueports/grips/fullstock remainprotected','R_min_SOURCE_mm':12.4});continue
 try:
  gap=SharedSourceGPIO32.distToShape(s)[0];vol=0
  if gap<1e-7:
   co=SharedSourceGPIO32.common(s)
   if co.Faces:co.check(True);assert co.isValid();vol=co.Volume
  rows.append({'other':n,'gap_mm':gap,'common_mm3':vol,'hold':gap<1.25-1e-7})
 except Exception as e:rows.append({'other':n,'error':str(e),'hold':True,'meaning':'UNRESOLVED_NOT_CONTACT'})
gap=SharedSourceGPIO32.distToShape(BodyOuter31.Shells[0])[0];outside=SharedSourceGPIO32.cut(BodyOuter31).Volume
r={'id':'SHARED_SOURCE_GPIO_C0_FULL_GALLERY_PREFLIGHT','review_turn':'01a19de0-cf99-7c90-a2b0-353796a57b9d','status':'HOLD_RIGID_ALLOCATION' if any(x['hold'] for x in rows) or gap<3.25 or outside>1e-7 else 'SHARED_GALLERY_FREE_SPACE_SCOPED_ONLY','rows':rows,'occupied_flexible_members':members,'section_required_mm':[9.15,3.9],'section_available_mm':[10,10],'outline_gap_mm':gap,'outside_mm3':outside,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':g,'open':['Fourentryexit identities/order/directions and continuousR12.4SOURCE/R10GPIO','changed full220 SOURCE balance, allprefixes/grips untouched','currentGPIO installedlength and30reserve','H1/U1northfunctionalretention/other9/head/global123'],'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-shared-SOURCE-GPIO-gallery-c0-preflight.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('SHARED_GALLERY',json.dumps(r),flush=True)

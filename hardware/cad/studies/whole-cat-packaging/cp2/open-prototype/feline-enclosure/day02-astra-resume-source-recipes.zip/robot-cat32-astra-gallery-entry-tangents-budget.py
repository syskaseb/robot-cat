tick=time.perf_counter();cpu=time.process_time()
d=json.loads((OUT/'day30-four-factory-common-regions.json').read_bytes());red=d['current_foreign_lower_ingress_proposal']['red_rows'];black=d['current_foreign_coupled_whole_proposal']['black_rows'];sourcepaths={};recipes={}
for n,rr in [('XP02.source',red),('XP03.source',black)]:
 edges=[]
 for row in rr:
  if row['kind']=='line':e=Part.makeLine(A.Vector(*row['start']),A.Vector(*row['end']))
  else:e=Part.Arc(A.Vector(*row['start']),A.Vector(*row['mid']),A.Vector(*row['end'])).toShape()
  edges.append(e)
 sourcepaths[n]=Part.Wire(edges);recipes[n]=rr
for n,sign in [('XL07',1),('XL10',-1)]:
 w=path.copy();w.translate(v(lat*(1.27*math.sqrt(2))*sign));sourcepaths[n]=w
rows=[]
for n,w in sourcepaths.items():
 cut=w.common(SharedSourceGPIO32);fields=[]
 for e in cut.Edges:
  for side,param in [('first',e.FirstParameter),('last',e.LastParameter)]:
   pos=e.valueAt(param);bounds=[]
   for axis,lo,hi in [('x',31,55),('y',4,14),('z',80,90)]:
    for label,x in [('low',lo),('high',hi)]:
     if abs(getattr(pos,axis)-x)<1e-5:bounds.append(axis+':'+label)
   if bounds:fields.append({'boundaries':bounds,'centre_mm':list(pos),'tangent_geometric':list(e.tangentAt(param)),'note':'Geometric cut-edge tangent; source path direction explicitly true-source-to-dock for SOURCE and upperbay-to-GPIO for logic. Accounting boundary is not fixed connector.'})
 rows.append({'member':n,'centreline_length_in_declared_gallery_mm':sum(e.Length for e in cut.Edges),'fields':fields,'full_original_rows_or_S_length_mm':w.Length})
geometry=d['current_foreign_functional_candidate']['geometry'];sourcepins=[x for x in geometry if x['name'] in ['Underdeck:SOURCE:XP02.source','Underdeck:SOURCE:XP03.source']]
stock=[]
for n,rr,debit in [('XP02.source',red,49),('XP03.source',black,20)]:
 total=sum(x['length_mm'] for x in rr)+debit
 stock.append({'member':n,'physical_id':n+'/extra','minimum_unit_mm':220,'row_total_mm':sum(x['length_mm'] for x in rr),'fixed_debit_outside_rows_mm':debit,'full_current_debit_mm':total,'remaining_before_any_change_mm':220-total,'existing_first9_in_curved_prefix_not_additional':True,'changed_interior_balance_NOT_received':True})
r={'id':'CURRENT37_FOUR_GALLERY_FIELDS_TANGENTS_AND_FACTORY_BASIS','reviewer_ledger_turn':'01a19de2-d2d9-7fe0-a639-b5ff673f754c','source_chain':'build-coupled-whole -> build-lower-whole replaces red -> lowercorrection preservesroutes -> functionalretirement -> rootclearsave current37','source_archive':d['current_foreign_functional_candidate']['archive'],'source_archive_sha256':d['current_foreign_functional_candidate']['archive_sha256'],'source_member_pins':sourcepins,'source_recipes':recipes,'fields':rows,'stock':stock,'correction':'Currentred is lower-ingress, not old vertically-translated sharedgallery. Oldblack164.384 and red215.097 are not this current37. Do not consume those budgets.','GPIO_policy':'Distinct purchased600 units, boardendfittrimonly/factoryPi contacts retained; fullcurrentprefixes+transport+bareends+source30 each, no extra9 atseam. NewinstalledlengthOPEN.','status':'CURRENT_BOUNDARY_DIRECTIONS_AND_STOCK_RECEIVED_CONTINUOUS_FOUR_MEMBER_ASSIGNMENT_OPEN','next':'Use these four actual field pairs and current lower-red topology for one ordered shared-region solution. Free10x10 and flat9.15x3.9 are not R/continuity proof; no thirdS offset or wirecontactclaim.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-shared-gallery-current-fields-stock.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GALLERY_STOCK_FIELDS',json.dumps({'fields':rows,'stock':stock,'seconds':r['operation_seconds'],'CPU':r['process_cpu_seconds']}),flush=True)

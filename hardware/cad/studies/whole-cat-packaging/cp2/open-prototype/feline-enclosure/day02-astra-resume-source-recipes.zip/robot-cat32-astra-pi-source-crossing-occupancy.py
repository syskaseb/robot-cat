tick=time.perf_counter();cpu=time.process_time()
# Named hazard: SOURCE passes through continuous capsule reservation of two spaced GPIO cores.
# Only the two existing S fields, no new centreline: distinguish occupied full profiles from empty inter-core region.
sep=1.27*math.sqrt(2);parts={};manifest=[];arc=OUT/'day02-astra-PiGPIO2-local-crossing-full-profiles.breps.zip';assert not arc.exists()
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as f:
 for name,sign in [('XL07',1),('XL10',-1)]:
  wirepath=path.copy();wirepath.translate(v(lat*sep*sign));centre=start+lat*sep*sign
  circle=Part.Wire([Part.makeCircle(1.1,v(centre),v(u))]);s=wirepath.makePipeShell([circle],True,False);s.check(True);assert s.isValid() and len(s.Solids)==1;parts[name]=s
  raw=s.exportBrepToString().encode();entry=str(len(manifest))+'.brep';f.writestr(entry,raw);manifest.append({'name':name+':OD1p4_plus_edge0p4_local_crossing','entry':entry,'sha256':hashlib.sha256(raw).hexdigest()})
 f.writestr('manifest.json',json.dumps({'geometry':manifest}))
rows=[]
for n,s in parts.items():
 t=CurrentC1Selected32['Underdeck:SOURCE:XP03.source'];gap=s.distToShape(t)[0];co=s.common(t) if gap<1e-7 else None;vol=0
 if co is not None and co.Faces:co.check(True);assert co.isValid();vol=co.Volume
 rows.append({'core':n,'capacity_gap_mm':gap,'common_mm3':vol,'full_GPIO_radius_mm':1.1,'nominal_GPIO_radius_mm':.7,'SOURCE_radius_mm':.925,'GPIO_outer_allowance_mm':.4,'separated_full_profiles':gap>1e-7})
r={'id':'PI_SOURCE_LOCAL_CROSSING_OCCUPIED_PROFILE_PROOF','hazard':'Shared capsule includes empty gap between two real spaced GPIO1.4 cores; existing SOURCE1.85 crosses this accounting region. Need local occupied-profile proof before claiming shared region, not123wiremodels.','axis_unchanged':True,'R12_unchanged':True,'real_GPIO_endpoints_retained':True,'rows':rows,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':manifest,'status':'LOCAL_OCCUPIED_PROFILES_SEPARATED' if all(x['separated_full_profiles'] for x in rows) else 'SHARED_OCCUPANCY_UNRESOLVED_NOT_RIGID_CONTACT','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-PiGPIO2-local-crossing-full-profiles.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GPIO_SOURCE_OCCUPANCY',json.dumps(r),flush=True)

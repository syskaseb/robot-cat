tick=time.perf_counter();cpu=time.process_time()
cap=Current32['Station:RL_G:common_channelled_cap_exterior']
fixed=cap.common(ibox31([32,61,-1],[55,65.6,9]))
pressure=cap.common(ibox31([32,65.6,-1],[55,70,9]))
bearing=Current32['Upper:W041_side_bearing_reservation']
strap=C1Parts32['front_fixed_grip_strap']
C1Functional32={'fixed_full9':fixed,'removable_full9':pressure,'strap':strap,'bearing':bearing}
rows=[]
def c1proof(a,b,kind):
 s=C1Functional32.get(a,Current32.get(a));t=C1Functional32.get(b,Current32.get(b))
 gap=s.distToShape(t)[0];co=s.common(t);vol=co.Volume if co.Faces else 0
 rows.append(dict(a=a,b=b,kind=kind,gap_mm=gap,common_mm3=vol))
c1proof('fixed_full9','strap','positive_fixed_material_joint')
c1proof('bearing','strap','positive_same_bolt_mount_material_joint')
c1proof('removable_full9','strap','removable_pressure_half_no_material_intersection')
for i,x in enumerate([36.5,41.25,46,50.75]):
 n='real_jacket_first9:'+str(i);C1Functional32[n]=Part.makeCylinder(1.55,9,A.Vector(x,65.6,8.5),A.Vector(0,0,-1))
 for half in ['fixed_full9','removable_full9','strap']:
  c1proof(half,n,'full9_insulated_jacket_no_material_intersection')
for n in ['CapScrew:W041_Joint:0','CapScrew:W041_Joint:1','CapNut:W041_Joint:0','CapNut:W041_Joint:1','Transverse:CaseCap:W041_Joint']:
 c1proof('strap',n,'same_W041_mount_actual_hardware_fit_pending_context')
for n in Current32:
 if n.startswith('Station:RL_G:band_') or n=='Station:RL_G:one_common_band_head':
  c1proof('strap',n,'retained_full_band_head_no_intersection')
union=fixed.fuse(strap).fuse(bearing).removeSplitter()
C1Functional32['fixed_bearing_union']=union
r={'id':'COMMON_FIXTURE_C1_FUNCTIONAL_CLASSIFICATION_PROOF','status':'LOCAL_MATERIAL_PROOF_ONLY_FULL_ACCESS_AND_PRESSURE_PENDING','no_pose_change':True,'no_counter_reset':True,'rows':rows,'union':{'valid':union.isValid(),'solids':len(union.Solids),'volume_mm3':union.Volume},'halves':{n:{'valid':s.isValid(),'solids':len(s.Solids),'volume_mm3':s.Volume,'z_length_mm':s.BoundBox.ZLength} for n,s in [('fixed',fixed),('pressure',pressure)]},'source':'Same current channelled RL_G exterior, exact Y65.6 split from reviewed C1; actual four selected port positions and OD3.1 first9. No new offset or purchased change. No shrink of foreign1.25. Physical compression/pull fit remains phase2; functional closure/access still to receive.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-functional-material-proof.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'))
print('C1_FUNCTIONAL_MATERIAL',json.dumps(r),flush=True)

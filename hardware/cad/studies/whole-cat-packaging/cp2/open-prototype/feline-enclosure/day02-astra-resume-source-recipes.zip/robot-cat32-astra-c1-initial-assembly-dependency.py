tick=time.perf_counter();cpu=time.process_time()
# Conservative full rail sweep from inboard -Y, before battery/rail lower jaws.
# Covers every rail cross-section throughout final20mm translation; no samples.
b=Current32['Ref_Material_P0_SideLeft22_0_0'].BoundBox
railSweep=ibox31([b.XMin,b.YMin-20,b.ZMin],[b.XMax,b.YMax,b.ZMax])
targets={'positivefoundation':Current32['Underdeck:PositiveFoundation'],**C1Changed32}
targets.update({n:s for n,s in Current32.items() if n=='Upper:W041_side_bearing_reservation' or n.startswith(('CapScrew:W041_Joint:','CapNut:W041_Joint:','Station:RL_G:','SourceRoot:W041:','W041:custom9:')) or n in ['Transverse:CaseCap:W041_Joint','W041:custom:fullsolid','W041:factory:fullsolid'] or ('W041' in n and 'case' in n.lower())})
rows=[]
for n,s in targets.items():
 sb=s.BoundBox;lower=bbox_lower_bound(railSweep.BoundBox,sb)
 if lower>1e-7:rows.append({'part':n,'full_swept_cover_lower_mm':lower,'common_mm3':0});continue
 extent=[min(b.XMax,sb.XMax)-max(b.XMin,sb.XMin),min(b.YMax,sb.YMax)-max(b.YMin-20,sb.YMin),min(b.ZMax,sb.ZMax)-max(b.ZMin,sb.ZMin)]
 if min(extent)<=1e-7:rows.append({'part':n,'common_mm3':0,'proof':'plane-only full bounding supports','extent':extent});continue
 gap=railSweep.distToShape(s)[0];co=railSweep.common(s) if gap<1e-7 else None
 rows.append({'part':n,'gap_mm':gap,'common_mm3':co.Volume if co is not None and co.Faces else 0,'proof':'full conservative continuous rail sweep'})
driver=json.loads((OUT/'day02-astra-common-fixture-c1-driver-context.json').read_bytes())
remaining=[r for r in driver['rows'] if r['contact_material'] and r['other'] not in ['Ref_Material_P0_SideLeft22_0_0','BatteryStrapCurrent2']]
r={'id':'C1_BOUNDED_INITIAL_ASSEMBLY_DEPENDENCY','status':'HOLD_SWEEP_COVER_INTERSECTION_NOT_ACTUAL_CONTACT' if any(x['common_mm3']>1e-7 for x in rows) else 'LOCAL_INITIAL_ASSEMBLY_DEPENDENCY_RECEIVED','source':'feline_shared_frame.build: clampseat bearing on TopClampPad; lowerjaws and screws are separate retained components. body_shell_scope independent rail-fasteners graph is provenance only; continuous conservative railcover here provides added geometric evidence, not full physical assembly proof.','driver_material_blocks_after_named_deferred_parts':remaining,'rail_inboard_final_translation_mm':20,'rail_sweep_bounds_mm':saved_bounds(railSweep),'rows':rows,'dependency_order':['W041 realcase/cap/nuts preloaded on common fixture; R3x43 tightening before SideLeft22/BatteryStrap2. All other current1288 driver operands unchanged and already received; no material blocks remain after those two deferred actors.','Fixture is supported on bench before its clamp seats bear on frame; no dependency on W041 tightening after the structural rail is present.','SideLeft22 approaches from inboard for final20mm under positivefoundation; lower rail clamp jaws/screws and battery strap not yet closed. Keep full rail, then fit its original front/rear fasteners and clamp lower jaws.','Close battery strap and complete remaining module/region installation. N08 repairs and whole robot installation path remain separate; this proves local W041/fixture/rail dependency only.'],'no_fasteners_or_purchased_material_removed':True,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-initial-assembly-dependency.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_INITIAL_ORDER',json.dumps(r),flush=True)

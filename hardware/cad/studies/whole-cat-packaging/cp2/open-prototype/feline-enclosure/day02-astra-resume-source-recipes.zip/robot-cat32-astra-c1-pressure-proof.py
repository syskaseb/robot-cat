tick=time.perf_counter();cpu=time.process_time()
# Same reviewed external cap envelope and port axes. Material completion only:
# remove the inherited +.15 channel allowance and provide a .2 closing seam.
# No jacket, bought case, bolt, strap, source position, band/head or margin moved.
outer=ibox31([32.95,62.05,-.5],[54.3,69.15,8.5])
channels=Part.makeCompound([C1Functional32['real_jacket_first9:'+str(i)] for i in range(4)])
nominal=outer.cut(channels)
fixed=nominal.common(ibox31([32,61,-1],[55,65.5,9]))
pressure=nominal.common(ibox31([32,65.7,-1],[55,70,9]))
rows=[]
for i in range(4):
 jacket=C1Functional32['real_jacket_first9:'+str(i)]
 for n,s in [('fixed',fixed),('pressure',pressure)]:
  common=s.common(jacket);area=s.common(jacket.Shells[0]).Area
  rows.append({'port':i,'half':n,'contact_area_mm2':area,'common_mm3':common.Volume if common.Faces else 0,'gap_mm':s.distToShape(jacket)[0],'full_axial_mm':s.BoundBox.ZLength})
joint=fixed.common(C1Parts32['front_fixed_grip_strap']).Volume
body=fixed.fuse(C1Parts32['front_fixed_grip_strap']).fuse(Current32['Upper:W041_side_bearing_reservation']).removeSplitter()
C1Pressure32={'fixed9_nominal_contact':fixed,'removable9_nominal_contact':pressure,'fixed_bearing_material':body}
loop=2*(21.35+7.1+2*1.2)
r={'id':'C1_SAME_ENVELOPE_FUNCTIONAL_PRESSURE_COMPLETION','status':'NOMINAL_CONTACT_AND_CLOSURE_PLAN_NOT_PHYSICAL_PULL_PASS','no_external_allocation_change':True,'no_counter_reset':True,'basis':'plan_feline_underframe_jacket_retention.py uses full actual jacket profiles for nominal contact plus explicit physical OD/pull gate. Previous source exterior R1.7 is access allowance, not proof of pressure. These two full9 nominal contact halves occupy same reviewed exterior; .2 face separation gives tightening travel, no jacket OD reduction. Band remains complete original upper-envelope stock.','rows':rows,'fixed_strap_common_mm3':joint,'union_valid':body.isValid(),'union_solids':len(body.Solids),'closing_seam_mm':.2,'band_stock':{'selected_T18I100_mm':100,'full_neutral_loop_rectangular_upper_mm':loop,'closure_head_tail_allowance_mm':25,'remaining_mm':100-loop-25,'width_mm':2.5,'thickness_mm':1.2,'head_complete_envelope_mm':[6,6,6]},'assembly':'Lay all four actual first9 fields onto fixed half before applying pressure half and full band. Source case/port identities unchanged. Nominal equal-OD contact on each half; physical pressure, actualOD and individual pull test phase2. No pretense that .15 clearance clamps.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-nominal-pressure-proof.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_PRESSURE',json.dumps(r),flush=True)

from pathlib import Path
import subprocess,hashlib,json,zipfile
root=Path('C:/Users/Sysq/PycharmProjects/robot-cat-mechanical');out=root/'hardware/cad/studies/whole-cat-packaging/cp2/open-prototype/feline-enclosure'
def git(*args,input=None):return subprocess.check_output(['git',*args],cwd=root,input=input)
staged=git('diff','--cached','--name-only').decode().splitlines();assert all(Path(n).name.startswith('day02-astra-') for n in staged),'Other staged changes; do not include'
card=root/'hardware/HOBBY_COMPLETION_PLAN.md';b=card.read_bytes();b=b.replace(b'3a2e7b187e38b0938548c408b4f6ddbf98a75b2ae89e931a362ffc2531fb072a7',hashlib.sha256((out/'day02-astra-common-fixture-c1-scoped-constructive-receipt.json').read_bytes()).hexdigest().encode());card.write_bytes(b)
files=sorted(out.glob('day02-astra-*'));files.append(out/'day30-four-factory-common-regions.json')
expected={}
for p in files:
 raw=p.read_bytes()
 if p.suffix=='.zip':
  with zipfile.ZipFile(p) as z:
   assert z.testzip() is None
   man=json.loads(z.read('manifest.json'));rows=man if isinstance(man,list) else man.get('geometry',[man])
   for r in rows:assert hashlib.sha256(z.read(r['entry'])).hexdigest()==r['sha256']
 rel=p.relative_to(root).as_posix();blob=git('hash-object','-w','--stdin',input=raw).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,rel);expected[rel]=raw
rel=card.relative_to(root).as_posix();marker=b'## Historia okna RL 29.10.2026';old=git('show','HEAD:'+rel);raw=b.split(marker,1)[0]+marker+old.split(marker,1)[1];blob=git('hash-object','-w','--stdin',input=raw).decode().strip();git('update-index','--add','--cacheinfo','100644',blob,rel);expected[rel]=raw
git('commit','-m','Preserve C1 functional common fixture and scoped assembly evidence')
for rel,raw in expected.items():assert git('show','HEAD:'+rel)==raw,rel
print('EXACT_BYTES_COMMIT',git('rev-parse','--short','HEAD').decode().strip(),'files',len(expected),'working historical tail untouched')

from pathlib import Path
import os
_restore_source=Path(os.environ['TEMP'],'robot-cat29-resume-n01.py').read_text(encoding='utf-8')
exec(_restore_source[:_restore_source.index('fam=json.loads')])
restore_tick=time.monotonic();restore_cpu=time.process_time();RestorePins30={}
def saved_bounds(s):
 b=s.BoundBox;return [[b.XMin,b.YMin,b.ZMin],[b.XMax,b.YMax,b.ZMax]]
bounds_data30=saved_bounds
def load_frozen30(filename):
 p=OUT/filename;r=json.loads(p.read_text(encoding='utf-8'));arc=Path(r['bundle']);arc=arc if arc.is_absolute() else (OUT/arc if (OUT/arc).exists() else ROOT/arc)
 assert hashlib.sha256(arc.read_bytes()).hexdigest()==r['bundle_sha256'],filename
 shapes={}
 with zipfile.ZipFile(arc) as z:
  for row in r['geometry']:
   raw=z.read(row['entry']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];s=Part.Shape();s.importBrepFromString(raw.decode());shapes[row['name']]=s
 RestorePins30[filename]=dict(manifest_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),archive_sha256=r['bundle_sha256'],actors=len(shapes))
 return r,shapes
OutboardPacket30,Shelf=load_frozen30('day30-outboard-U1-space.json');CarrierReceipt30,Mounts30=load_frozen30('day30-u1-shared-carrier.json')
U1CoreNames=set(OutboardPacket30['native_bought_core_names']);assert len(U1CoreNames)==146
U1OutboardPorts=OutboardPacket30['ports'];Carrier30=Mounts30['SharedPositiveFoundationU1'];Clamps30={n:s for n,s in Mounts30.items() if n.startswith('C30:')}
PiPacket30,PiRequired30=load_frozen30('day30-current-pi-required-space.json');assert len(PiRequired30)==17
from registered_fpi_space import construct
FPIReserve,FPIInfo=construct(OUT);PlanningReservations29={FPIInfo['actor']:FPIReserve,**PiRequired30};occupied.update(PlanningReservations29)
SplitReceipt30,Split30=load_frozen30('day30-split-front-regions.json');SplitKind30={r['name']:r['kind'] for r in SplitReceipt30['geometry']}
Scoped23,ScopedActors23=load_frozen30('day30-front-jpwm-u1-current-space.json')
for filename,digest in Scoped23['frozen_source_packets_sha256'].items():assert hashlib.sha256((OUT/filename).read_bytes()).hexdigest()==digest,filename
retired30=set(Shelf)|{n for n in occupied if n.startswith(('U1Relief:','U1Carrier:','U1Local:','U1Five:'))}|{'CurrentFoundation:FoundationRail:1','CurrentFoundation:FoundationFlange:1','FrontShared:factory_rib','FrontShared:custom_rib','FLArcGuide'}|{n for n in occupied if n.startswith('ForeFHAC:') and n!='ForeFHAC:case'}
CurrentFixed30={n:s for n,s in occupied.items() if n not in retired30};CurrentFixed30.update({n:Shelf[n] for n in U1CoreNames});CurrentFixed30.update(Mounts30)
ActiveScene30=dict(CurrentFixed30);ActiveLocalCapacity30={}
for row in SplitReceipt30['geometry']:
 n=row['name'];kind=row['kind']
 if kind.startswith('local_'):ActiveLocalCapacity30[n]=Split30[n]
 elif kind!='shared_capacity_candidate_not_material':ActiveScene30[n]=Split30[n]
for n in Scoped23['exact_retire_then_replace_actor_names']:ActiveScene30.pop(n,None)
for row in Scoped23['geometry']:
 n=row['name']
 if row['role'] in ('local_pair_capacity_reservation','nominal_fixed_terminal_or_jacket'):ActiveLocalCapacity30[n]=ScopedActors23[n]
 else:ActiveScene30[n]=ScopedActors23[n]
FourRegionProposal30=json.loads((OUT/'day30-four-factory-common-regions.json').read_text(encoding='utf-8'));rec=FourRegionProposal30['current_foreign_flat_front_candidate'];arc=OUT/rec['archive'];assert hashlib.sha256(arc.read_bytes()).hexdigest()==rec['archive_sha256']
FlatFront30={}
with zipfile.ZipFile(arc) as z:
 for row in rec['geometry']:
  assert row['entry'].startswith('flat-shared/');raw=z.read(row['entry']);assert hashlib.sha256(raw).hexdigest()==row['sha256'];s=Part.Shape();s.importBrepFromString(raw.decode());FlatFront30[row['name']]=s
assert len(FlatFront30)==34
retire_final=set(FourRegionProposal30['retired_in_this_correction'])|{'CradleLowEdge:open:0','CradleLowEdge:open:1','CurrentFoundation:BankBedCurrent:-1:JPWMRooted','SharedPositiveFoundationU1','DAY18:XP02:band','DAY18:XP02:head'}
FourThirdContext30={n:s for n,s in ActiveScene30.items() if n not in retire_final and n not in FlatFront30}
# Three exact still-current tape reservations, not an obsolete cup rebuild.
for n,lo,hi in [('Fore',[-112.15,51.65,86.8],[-108.15,73.65,87.3]),('Rear',[-65.15,51.65,86.8],[-61.15,73.65,87.3]),('HighMiddle',[-108.15,69.65,86.8],[-65.15,73.65,87.3])]:
 FourThirdContext30['FHY4905:'+n]=Part.makeBox(*(np.array(hi)-lo),A.Vector(*lo))
UnderdeckContext30=dict(FourThirdContext30)
CurrentWholeFront30={**FourThirdContext30,**FlatFront30}
ShoulderPacket30=json.loads((OUT/'day30-paired-front-shoulder.json').read_text(encoding='utf-8'));outer=OUT/ShoulderPacket30['brep'];assert hashlib.sha256(outer.read_bytes()).hexdigest()==ShoulderPacket30['brep_sha256'];ShoulderOuter30=Part.Shape();ShoulderOuter30.read(str(outer))
motion=json.loads((OUT/'motion-layout.json').read_text(encoding='utf-8'));axes=json.loads((ROOT/'hardware/simulation/p0/e6-leg-compatibility.json').read_text(encoding='utf-8'))['axes']
FlatForeignRows30=rec['foreign_rows'];FlatOwnRows30=rec['own_rows'];fp=FourRegionProposal30['current_foreign_flat_crossing_proposal'];proposal=FourRegionProposal30['current_foreign_next_whole_proposal']
restore_report=dict(pid=os.getpid(),session_id=70577,MAIN_mm=datum,base_native_objects=1180,base_material_actors=len(material),moving_sources=len(restMotion),saved_motion_poses=len(motion['poses'][:36]),stock_actors=len(StockStrictConstraints),U1_core_actors=len(U1CoreNames),U1_carrier_actors=len(Mounts30),Pi_reservations=len(PiRequired30),split_actors=len(Split30),scoped_source_actors=len(ScopedActors23),current_flat_actors=34,current_fixed_context_actors=len(FourThirdContext30),retired_final=sorted(retire_final),foreign_received=204,foreign_holds=len(rec['remaining_foreign_holds']),source_pins=RestorePins30,flat_archive_sha256=rec['archive_sha256'],elapsed_seconds=time.monotonic()-start29,process_cpu_after_base_seconds=time.process_time()-restore_cpu,old_collision_checks_repeated=False,N01_complete=False)
FourRegionProposal30['current_native_restore_receipt']=restore_report;FourRegionProposal30['current_runtime_roles'].update(restore_status='CURRENT_SOURCES_IMPORTED_SOURCE_RECONCILIATION_NEXT')
(OUT/'day30-four-factory-common-regions.json').write_text(json.dumps(FourRegionProposal30,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('CURRENT_RESTORE',json.dumps({k:v for k,v in restore_report.items() if k!='source_pins'}),flush=True)

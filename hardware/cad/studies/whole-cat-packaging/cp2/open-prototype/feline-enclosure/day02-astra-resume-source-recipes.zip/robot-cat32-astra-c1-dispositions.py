tick=time.perf_counter();cpu=time.process_time();plane=[]
for r in C1ContextRows32:
 if r['classification']!='ERROR_NOT_CONTACT':continue
 a=C1Changed32[r['part']].BoundBox;b=Current32[r['other']].BoundBox
 lo=[max(a.XMin,b.XMin),max(a.YMin,b.YMin),max(a.ZMin,b.ZMin)];hi=[min(a.XMax,b.XMax),min(a.YMax,b.YMax),min(a.ZMax,b.ZMax)]
 ext=[y-x for x,y in zip(lo,hi)];assert min(ext)<=1e-7,(r,ext)
 plane.append({'part':r['part'],'other':r['other'],'intersection_extent_mm':ext,'disposition':'FULL_VALID_EXTERNAL_BOUNDS_PROVE_NO_POSITIVE_VOLUME; own case-end plane or band-bearing plane. Invalid planar BOP result is not contact proof.'})
alias=Current32['CurrentFoundation:ClampNeck:4'].cut(Current32['Underdeck:PositiveFoundation'])
alias_volume=alias.Volume if alias.Faces else 0
# Full pressure-half installation corridor from 5mm outboard. Own band/head is
# fitted afterward; cap is split, so no connector threading or case removal.
envelope=ibox31([32.95,65.7,-.5],[54.3,74.15,8.5]);C1PressureAccess32=envelope;access=[]
omit={'Station:RL_G:common_channelled_cap_exterior','W041Carrier:far_upper_post'}
omit|={n for n in Current32 if n.startswith('Station:RL_G:band_') or n=='Station:RL_G:one_common_band_head'}
for n,s in Current32.items():
 if n in omit or bbox_lower_bound(envelope.BoundBox,s.BoundBox)>1e-7:continue
 b=s.BoundBox;e=envelope.BoundBox
 extent=[min(e.XMax,b.XMax)-max(e.XMin,b.XMin),min(e.YMax,b.YMax)-max(e.YMin,b.YMin),min(e.ZMax,b.ZMax)-max(e.ZMin,b.ZMin)]
 if min(extent)<=1e-7:access.append({'other':n,'disposition':'full_bound_plane_no_positive_volume','extent':extent});continue
 gap=envelope.distToShape(s)[0];co=envelope.common(s) if gap<1e-7 else None
 access.append({'other':n,'gap_mm':gap,'common_mm3':co.Volume if co is not None and co.Faces else 0,'status':'CONSERVATIVE_ENVELOPE_NOT_ACTUAL_PRESSURE_CONTACT'})
r={'status':'FUNCTIONAL_INTERFACE_DISPOSITIONS_ASSEMBLY_ORDER_REQUIRED','plane_dispositions':plane,'clampneck4_outside_positivefoundation_mm3':alias_volume,'roots':'farleg/bearing positive1.000948 is same existing printed W041 support; return/header positives to ClampNeck4 are same fixed foundation joint, not independent hardware. FLGprint remains complete fixed print with positive6.55 header joint; received FLG port/cap/band retained. No cut or metal contact waived.','pressure_half_access':access,'screw_assembly':'Straight R3x43 drivers intersect structural SideLeft22 and BatteryStrapCurrent2 in installed scene. Thus no assembled-robot straightdriver access claim. Initial assembly must preload/tighten W041 case/cap/nuts on its common fixture BEFORE fitting the independently fastened SideLeft22 structural rail and battery strap. body_shell_scope.py identifies separate front/rear-frame-to-side fasteners (four M2.5x12 plus nuts); do not remove/alter selected rail. N08 repair sequence remains unqualified. Need verify source mount order and no required retightening after rail install, not pretend installed toolclear.','own_foreign':'Material identity of strap with same W041 bolt boss demonstrated by valid1solid and retained nut/bore/cap geometry. The1.165180 gap is own hardware positiveclearance, not a foreign1.25 failure. Full functional classification remains conditional on assembly order; all unrelated foreign1.25 retained.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-functional-dispositions.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_DISPOSITIONS',json.dumps(r),flush=True)

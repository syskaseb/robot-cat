tick=time.perf_counter();cpu=time.process_time();LocalNeighborRows32=[]
own={('top_header','Underdeck:PositiveFoundation'),('far_leg','Underdeck:PositiveFoundation'),('near_leg','Underdeck:PositiveFoundation'),('far_leg','SourceRoot:W041:custom9:link'),('far_leg','W041:custom9:pad'),('front_grip_heel','Upper:W041_side_bearing_reservation'),('front_grip_heel','Station:RL_G:common_channelled_cap_exterior'),('near_leg','Upper:W041_side_bearing_reservation')}
LocalTasks32=[]
for n,s in Trial32.items():
 for m,b in Current32.items():
  if m=='W041Carrier:far_upper_post' or (n,m) in own:continue
  if bbox_lower_bound(s.BoundBox,b.BoundBox)>=1.25-1e-6:continue
  LocalTasks32.append((n,m,s,b))
LocalTasks32.sort(key=lambda x:(0 if ('RL_G' in x[1] or 'CapScrew:W041' in x[1] or 'CapNut:W041' in x[1]) else 1 if 'W041' in x[1] else 2))
print('LOCAL_FULL_NEIGHBORS_PREP',len(LocalTasks32),flush=True)
LocalCursor32=0
def local_neighbor_chunk32(seconds=15):
 global LocalCursor32
 t=time.perf_counter();c=time.process_time();start=LocalCursor32;rows=[]
 while LocalCursor32<len(LocalTasks32) and time.perf_counter()-t<seconds:
  n,m,s,b=LocalTasks32[LocalCursor32];r={'part':n,'other':m,'required_mm':1.25}
  if not b.Solids:r.update(hold=True,classification='PROFILE_METADATA_REQUIRED_NOT_CONTACT')
  else:
   try:
    gap,pts,_=s.distToShape(b);r.update(gap_mm=gap,witnesses=[[list(a),list(b)] for a,b in pts[:1]],hold=gap<1.25-1e-6)
    if gap<1e-7:
     b.check(True);assert b.isValid();co=s.common(b);r['common_mm3']=co.Volume if co.Faces else 0
   except Exception as e:r.update(hold=True,error=str(e),classification='UNRESOLVED_KERNEL_NOT_CONTACT')
  rows.append(r);LocalNeighborRows32.append(r);LocalCursor32+=1
  if r['hold']:break
 result={'status':'LOCAL_NEIGHBOR_HOLD' if any(x['hold'] for x in LocalNeighborRows32) else 'PARTIAL' if LocalCursor32<len(LocalTasks32) else 'LOCAL_ALL_NEIGHBORS_RECEIVED','start':start,'cursor':LocalCursor32,'total':len(LocalTasks32),'rows':rows,'operation_seconds':time.perf_counter()-t,'process_cpu_seconds':time.process_time()-c,'N01_complete':False,'no_detail_or_union_built':True}
 p=OUT/('day02-astra-common-fixture-c0-local-neighbors-%d-%d.json'%(start,LocalCursor32));assert not p.exists();p.write_bytes((json.dumps(result,indent=2)+'\n').encode());print('LOCAL_NEIGHBORS',LocalCursor32,len(LocalTasks32),result['operation_seconds'],result['process_cpu_seconds'],[x for x in rows if x['hold']],flush=True)
local_neighbor_chunk32()

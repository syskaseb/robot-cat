tick=time.perf_counter();cpu=time.process_time()
q=OUT/'day02-astra-whole-connected-regions-c1-proposal.json';assert hashlib.sha256(q.read_bytes()).hexdigest()=='5391e35e271535a1f89b3e1f4f8de4550fbe881d5d202d50e497ac7947429b3e'
z0=88.9; h=2.2
s1=Part.makeBox(28,5.4,h,A.Vector(5,91.35,z0))
a=Part.makeCylinder(15.7,h,A.Vector(33,81.05,z0)).cut(Part.makeCylinder(10.3,h+2,A.Vector(33,81.05,z0-1)))
a=a.common(Part.makeBox(16,16,h,A.Vector(33,81.05,z0)))
s2=Part.makeBox(5.4,36.05,h,A.Vector(43.3,45,z0))
PiTransport32=s1.fuse(a).fuse(s2).removeSplitter();PiTransport32.check(True);assert PiTransport32.isValid() and len(PiTransport32.Solids)==1
raw=PiTransport32.exportBrepToString().encode();arc=OUT/'day02-astra-Pi3-transport-c1.breps.zip';assert not arc.exists()
g=[{'name':'Pi3:shared_transport_5p4x2p2','entry':'0.brep','sha256':hashlib.sha256(raw).hexdigest()}]
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as f:f.writestr('0.brep',raw);f.writestr('manifest.json',json.dumps({'geometry':g}))
rows=[]
for n,s in CurrentC1Selected32.items():
 if bbox_lower_bound(PiTransport32.BoundBox,s.BoundBox)>=1.25:continue
 try:
  gap=PiTransport32.distToShape(s)[0];v=0
  if gap<1e-7:
   c=PiTransport32.common(s);c.check(True);assert c.isValid();v=c.Volume
  rows.append({'other':n,'gap_mm':gap,'common_mm3':v,'hold':gap<1.25-1e-7,'classification':'CAPACITY_ALLOCATION_NOT_WIRE_CONTACT; any ownseam requires actual functional disposition'})
 except Exception as e:rows.append({'other':n,'error':str(e),'hold':True,'classification':'UNRESOLVED_NOT_CONTACT'})
gap=PiTransport32.distToShape(BodyOuter31.Shells[0])[0];outside=PiTransport32.cut(BodyOuter31).Volume
r={'id':'WHOLE_REGIONS_C1_PI3_TRANSPORT','status':'HOLD' if any(x['hold'] for x in rows) or gap<3.25-1e-7 or outside>1e-7 else 'LOCAL_TRANSPORT_SEPARATED_CONNECTIONS_OPEN','rows':rows,'outline_gap_mm':gap,'outside_mm3':outside,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':g,'section_mm':[5.4,2.2],'axis_R_mm':13,'inner_full_region_R_mm':10.3,'axis_length_mm':28+13*math.pi/2+36.05,'open':['source3 elevations merge','storage entry continuity and30 usable service reserve','Pi recipient descent','North12 functional replacement full stock/root/outline','other9/head/global123 integration'],'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-Pi3-transport-c1-preflight.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('PI3_TRANSPORT',json.dumps(r),flush=True)

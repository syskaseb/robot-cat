tick=time.perf_counter();cpu=time.process_time()
# Same whole C1 hypothesis, named unresolved recipient descent. Full occupied shared space, not individual wires.
PiTurnBay32=Part.makeBox(28.6,31.3,2.2,A.Vector(25.7,16.7,92.9))
end=np.array([29.235024,0.943148,75.7]);u=np.array([-1/math.sqrt(2),-1/math.sqrt(2),0.]);lat=np.array([1/math.sqrt(2),-1/math.sqrt(2),0.]);up=np.array([0.,0.,1.]);R=12.;drop=18.3;theta=math.acos(1-drop/(2*R));run=2*R*math.sin(theta);start=end-u*run+up*drop
p0=start;p1=start+u*(R*math.sin(theta))-up*(R*(1-math.cos(theta)));p2=end
m1=start+u*(R*math.sin(theta/2))-up*(R*(1-math.cos(theta/2)))
m2=p1+u*(R*(math.sin(theta)-math.sin(theta/2)))-up*(R*(math.cos(theta/2)-math.cos(theta)))
v=lambda a:A.Vector(*[float(x) for x in a])
path=Part.Wire([Part.Arc(v(p0),v(m1),v(p1)).toShape(),Part.Arc(v(p1),v(m2),v(p2)).toShape()])
pts=[p0+lat*w+up*h for w,h in [(-2.9,-1.1),(2.9,-1.1),(2.9,1.1),(-2.9,1.1),(-2.9,-1.1)]]
profile=Part.Wire(Part.makePolygon([v(x) for x in pts]).Edges)
PiGPIODescent32=path.makePipeShell([profile],True,False);PiGPIODescent32.check(True);assert PiGPIODescent32.isValid() and len(PiGPIODescent32.Solids)==1
pieces={'Pi3:upper_accessible_turn_bay':PiTurnBay32,'PiGPIO2:full_S_descent':PiGPIODescent32}
arc=OUT/'day02-astra-Pi3-connected-turn-bay-c1.breps.zip';assert not arc.exists();geom=[]
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as z:
 for n,s in pieces.items():
  raw=s.exportBrepToString().encode();entry=str(len(geom))+'.brep';z.writestr(entry,raw);geom.append({'name':n,'entry':entry,'sha256':hashlib.sha256(raw).hexdigest(),'bounds':saved_bounds(s)})
 z.writestr('manifest.json',json.dumps({'geometry':geom}))
rows=[]
for n,s in pieces.items():
 for m,t in CurrentC1Selected32.items():
  if bbox_lower_bound(s.BoundBox,t.BoundBox)>=1.25:continue
  try:
   gap=s.distToShape(t)[0];vol=0
   if gap<1e-7:
    co=s.common(t);co.check(True);assert co.isValid();vol=co.Volume
   rows.append({'part':n,'other':m,'gap_mm':gap,'common_mm3':vol,'hold':gap<1.25-1e-7,'meaning':'Allocated shared capacity, not proof of actual flexible-wire contact. No unnamed own waiver.'})
  except Exception as e:rows.append({'part':n,'other':m,'error':str(e),'hold':True})
outline=[{'part':n,'gap_mm':s.distToShape(BodyOuter31.Shells[0])[0],'outside_mm3':s.cut(BodyOuter31).Volume} for n,s in pieces.items()]
r={'id':'WHOLE_C1_PI_CONNECTED_TURN_BAY','status':'HOLD' if any(x['hold'] for x in rows) else 'LOCAL_BAY_SCOPED_CONNECTIONS_OPEN','rows':rows,'outline':outline,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':geom,'GPIO2_start_mm':list(start),'GPIO2_end_centre_mm':list(end),'S_axis_R_mm':R,'inner_capacity_R_lower_mm':R-1.1,'theta_degrees':math.degrees(theta),'axis_length_mm':2*R*theta,'section_mm':[5.8,2.2],'identities':['XL07','XL10'],'source_declared_recipient_ends':'Existing H11/H6 full9 endpoint plane; no new terminal; H3/H5 not allocated in this2wire region','open':['H1 onward branch','central Z90 to turn bay Z94 continuous merge','source12 retention/outline','30 service reserve and wholecurrent installedlength','head/other9/current123 mapping'],'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-Pi3-connected-turn-bay-c1-preflight.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('PI_CONNECTED',json.dumps(r),flush=True)

tick=time.perf_counter();cpu=time.process_time()
p=OUT/'day02-astra-whole-connected-regions-c0-proposal.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='b58bb7609b35d51fecb7efec24b24571184d3039c381b5ceb598abb4f1737949'
PiStorage32=Part.makeCylinder(14.3,8.6,A.Vector(40,31,87.3)).cut(Part.makeCylinder(8.9,8.8,A.Vector(40,31,87.2)));PiStorage32.check(True);assert PiStorage32.isValid() and len(PiStorage32.Solids)==1
raw=PiStorage32.exportBrepToString().encode('utf-8');arc=OUT/'day02-astra-Pi3-storage-c0.breps.zip';assert not arc.exists()
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('0.brep',raw);z.writestr('manifest.json',json.dumps({'geometry':[{'name':'Pi3:full_annular_storage_capacity','entry':'0.brep','sha256':hashlib.sha256(raw).hexdigest()}]}))
rows=[]
for n,s in CurrentC1Selected32.items():
 if bbox_lower_bound(PiStorage32.BoundBox,s.BoundBox)>=1.25:continue
 try:
  gap=PiStorage32.distToShape(s)[0];co=PiStorage32.common(s) if gap<1e-7 else None;v=co.Volume if co is not None and co.Faces else 0
  if co is not None and co.Solids:co.check(True)
  rows.append({'other':n,'gap_mm':gap,'common_mm3':v,'hold':gap<1.25-1e-7,'meaning':'Storage capacity allocation, not physical contact of flexible wires'})
 except Exception as e:rows.append({'other':n,'hold':True,'error':str(e),'meaning':'UNRESOLVED_NOT_CONTACT'})
gap=PiStorage32.distToShape(BodyOuter31.Shells[0])[0];outside=PiStorage32.cut(BodyOuter31).Volume
r={'id':'WHOLE_REGIONS_C0_PI3_STORAGE_WEAKEST_PREFLIGHT','review_turn':'01a19dc5-9ac8-7a93-b451-01bf49d707dd','status':'HOLD_STORAGE_ALLOCATION' if any(x['hold'] for x in rows) or gap<3.25 or outside>1e-7 else 'SCOPED_STORAGE_VOLUME_SEPARATED_TRANSPORT_AND_LENGTH_OPEN','rows':rows,'outline_gap_mm':gap,'outside_mm3':outside,'required_foreign_mm':1.25,'required_outline_mm':3.25,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':[{'name':'Pi3:full_annular_storage_capacity','entry':'0.brep','sha256':hashlib.sha256(raw).hexdigest()}],'no_installed_wire_or_turn_transition_claim':True,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-Pi3-storage-c0-preflight.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('PI3_STORAGE_PREFLIGHT',json.dumps(r),flush=True)

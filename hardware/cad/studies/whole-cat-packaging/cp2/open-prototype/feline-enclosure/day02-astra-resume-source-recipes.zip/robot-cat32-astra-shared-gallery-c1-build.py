tick=time.perf_counter();cpu=time.process_time()
q=json.loads((OUT/'day02-astra-shared-SOURCE-GPIO-gallery-c1-proposal.json').read_bytes());assert q['correction_used']==1
from math import comb
polys=[xx32,yy32,zz32];degree=6;poles=[]
for k in range(degree+1):poles.append(A.Vector(*[float(sum(poly.coef[i]*comb(k,i)/comb(degree,i) for i in range(min(k,poly.degree())+1))) for poly in polys]))
curve=Part.BezierCurve();curve.setPoles(poles);newedge=curve.toShape()
err=max((curve.value(float(t))-A.Vector(*[float(poly(t)) for poly in polys])).Length for t in np.linspace(0,1,17));assert err<1e-8
oldedges=sourcepaths['XP03.source'].Edges;e7=oldedges[7];e10=oldedges[10]
pa=e7.Curve.parameter(A.Vector(*pA));pb=e10.Curve.parameter(A.Vector(*pB))
left=e7.Curve.toShape(e7.FirstParameter,pa);right=e10.Curve.toShape(pb,e10.LastParameter)
fullpath=Part.Wire(list(oldedges[:7])+[left,newedge,right]);assert abs(fullpath.Length+20-(160.6596600169126-24.55793843558799+newedge.Length))<1e-6
normal0=oldedges[0].tangentAt(oldedges[0].FirstParameter);circle=Part.Wire([Part.makeCircle(.925,oldedges[0].Vertexes[0].Point,normal0)])
GalleryBlackFull32=fullpath.makePipeShell([circle],True,False);GalleryBlackFull32.check(True);assert GalleryBlackFull32.isValid() and len(GalleryBlackFull32.Solids)==1
circle2=Part.Wire([Part.makeCircle(.925,A.Vector(*pA),A.Vector(*tA))]);GalleryBlackInterior32=Part.Wire([newedge]).makePipeShell([circle2],True,False);GalleryBlackInterior32.check(True);assert GalleryBlackInterior32.isValid()
arc=OUT/'day02-astra-shared-gallery-c1-black.breps.zip';assert not arc.exists();geom=[]
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as f:
 for n,s in [('XP03.source:full220_unit_changed_freeportion',GalleryBlackFull32),('XP03.source:changed_interior_full_profile',GalleryBlackInterior32)]:
  raw=s.exportBrepToString().encode();entry=str(len(geom))+'.brep';f.writestr(entry,raw);geom.append({'name':n,'entry':entry,'sha256':hashlib.sha256(raw).hexdigest(),'bounds':saved_bounds(s)})
 f.writestr('manifest.json',json.dumps({'geometry':geom}))
rows=[]
for n,s,req in [('XP02.source',CurrentC1Selected32['Underdeck:SOURCE:XP02.source'],0),('XL07_fullprofile',parts['XL07'],0),('XL10_fullprofile',parts['XL10'],0)]:
 try:
  gap=GalleryBlackFull32.distToShape(s)[0];vol=0
  if gap<1e-7:
   co=GalleryBlackFull32.common(s)
   if co.Faces:co.check(True);assert co.isValid();vol=co.Volume
  rows.append({'other':n,'gap_mm':gap,'common_mm3':vol,'hold':vol>1e-7,'criterion':'Full declared profile occupancy, not foreign1.25 between insulatedmembers'})
 except Exception as e:rows.append({'other':n,'error':str(e),'hold':True})
# Reject before dependent foreign when full own occupancy fails.
if not any(x['hold'] for x in rows):
 for n,s in CurrentC1Selected32.items():
  if n in ['Underdeck:SOURCE:XP02.source','Underdeck:SOURCE:XP03.source']:continue
  if bbox_lower_bound(GalleryBlackInterior32.BoundBox,s.BoundBox)>=1.25:continue
  gap=GalleryBlackInterior32.distToShape(s)[0];rows.append({'other':n,'gap_mm':gap,'hold':gap<1.25-1e-7,'criterion':'Actual foreign rigid/fullstock1.25'})
outlinegap=GalleryBlackInterior32.distToShape(BodyOuter31.Shells[0])[0];outside=GalleryBlackInterior32.cut(BodyOuter31).Volume
r={'id':'SHARED_SOURCE_GPIO_C1_ONE_ORDERED_BLACK','status':'OWN_OCCUPANCY_HOLD_STOP_NO_THIRD_OFFSET' if any(x['hold'] for x in rows) else 'SCOPED_ORDERED_LOCAL_GALLERY_RECEIVED_WHOLE_OPEN','rows':rows,'native_exact_polynomial_maxerror_mm':err,'new_interior_length_mm':newedge.Length,'whole_source_debit_mm':fullpath.Length+20,'factory_remaining_mm':220-fullpath.Length-20,'SOURCE_R_lower_math_mm':Rlower,'required_SOURCE_R_mm':12.4,'unchanged_prefix_and_ends':'Exact original edges0..6, retainedpart7 andpart10, original first9/factoryports/dock; no newdebit9. Same positions/tangents at two accounting cuts.','outline_gap_mm':outlinegap,'outside_mm3':outside,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':geom,'correction_used':1,'max_corrections':1,'current_source_replacement_selected':False,'open':['source12northretention/outline','Pi3fullentrymerge/H1/currentinstalledlength30slack','other9/head/whole123246','Changedmotion/assembly disposition for thislocalgallery ifown passes'],'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-shared-gallery-c1-black-receipt.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GALLERY_C1_RECEIPT',json.dumps(r),flush=True)

tick=time.perf_counter();cpu=time.process_time()
src=Path('C:/Users/Sysq/AppData/Local/Temp/robot-cat31-astra-motion-preflight-prepare.py').read_text(encoding='utf-8');exec(compile(src[:src.index('MotionCandidate31=')],'restore_saved36_transforms_only','exec'))
def read_geometry32(filename):
 p=OUT/filename;d=json.loads(p.read_bytes());arc=OUT/d['archive'];assert hashlib.sha256(arc.read_bytes()).hexdigest()==d['archive_sha256'];ans={}
 with zipfile.ZipFile(arc) as z:
  for r in d['geometry']:
   raw=z.read(r['entry']);assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=Part.Shape();s.importBrepFromString(raw.decode('utf-8'));ans[r['name']]=s
 return ans,d
OwnerFacing32,OwnerInfo32=read_geometry32('day31-astra-owner-facing-c0-receipt.json')
NearPort32,NearInfo32=read_geometry32('day31-astra-nearport-whole-c0-interfaces-receipt.json')
moving={n:s for n,s in OwnerFacing32.items() if n.endswith(':print')}
moving.update({n:s for n,s in NearPort32.items() if n.endswith((':cap',':head',':band',':region',':port14'))})
moving.update({n:s for n,s in OwnerFacing32.items() if n.endswith((':cap',':head'))})
assert len(moving)==17,(len(moving),list(moving))
MovingCurrent32={};MovingBounds32=[]
for pi in range(36):
 for n,s in moving.items():
  stage='Hip' if n.startswith(('Hip:','FL1:')) else 'Knee';rot,tr=next((R,T) for p,c,g,_,R,T in MotionEntries31 if p==pi and c=='RL' and g==stage)
  q=s.copy();q.Placement=placement(rot,tr)*q.Placement;MovingCurrent32[(pi,n)]=q;MovingBounds32.append(saved_bounds(q))
mb=np.array(MovingBounds32);mi=list(MovingCurrent32);rows=[];C1MotionPending32=[]
for n,s in C1Changed32.items():
 lo,hi=np.array(saved_bounds(s));distance=np.linalg.norm(np.maximum(np.maximum(MotionBounds31[:,0]-hi,lo-MotionBounds31[:,1]),0),axis=1)
 ids=np.flatnonzero(distance<1.25-1e-7)
 for i in ids:C1MotionPending32.append((n,'mechanical',int(i)))
 d2=np.linalg.norm(np.maximum(np.maximum(mb[:,0]-hi,lo-mb[:,1]),0),axis=1);ids2=np.flatnonzero(d2<1.25-1e-7)
 for i in ids2:C1MotionPending32.append((n,'current17',int(i)))
 outside=s.cut(BodyOuter31);gap=s.distToShape(BodyOuter31.Shells[0])[0]
 rows.append({'part':n,'outline_gap_mm':gap,'outside_mm3':outside.Volume if outside.Faces else 0,'mechanical_min_full_bound_mm':float(distance.min()),'current17_min_full_bound_mm':float(d2.min()),'mechanical_pending':len(ids),'current17_pending':len(ids2)})
r={'status':'CHANGED_C1_OUTLINE_AND_36_FULL_BOUNDS','rows':rows,'pending_exact_pairs':C1MotionPending32,'scope':scope,'mechanical_sources':108,'current_owned_moving_parts':17,'restored_sources':[OwnerInfo32['archive'],NearInfo32['archive']],'no_old_collision_tests_repeated':True,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-motion-outline.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_MOTION_OUTLINE',json.dumps(r),flush=True)

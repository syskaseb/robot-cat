tick=time.perf_counter();cpu=time.process_time()
stop=OUT/'day31-astra-common-fixture-stop-limit.json';assert hashlib.sha256(stop.read_bytes()).hexdigest()=='5c990ea28faf7d3b954cab99997bf425f7d79f8e87b3605f787efb3045418154'
sel=json.loads((OUT/'day31-astra-W026-complete-foot-carrier-c1-current-disposition.json').read_bytes());Wanted32=set(sel['composition_names']);Current32={n:s for n,s in {**G3IntegrationWorld31,**Current56}.items() if n in Wanted32};Source32={n:{'source':'named_base_context_or_current56'} for n in Current32};Archives32={};LoadPins32={}
def load_current32(filename):
 p=OUT/filename;d=json.loads(p.read_bytes());LoadPins32[filename]=hashlib.sha256(p.read_bytes()).hexdigest();rows=d['geometry'];rows=([dict(v,name=k) for k,v in rows.items()] if isinstance(rows,dict) else rows)
 for r in rows:
  n=r['name']
  if n not in Wanted32:continue
  arc=r.get('archive',d.get('archive',d.get('bundle')));arc=arc if isinstance(arc,str) else arc['path'];ap=OUT/arc
  if not ap.exists():ap=ROOT/arc
  sha=r.get('archive_sha256',d.get('archive_sha256',d.get('bundle_sha256')))
  if str(ap) not in Archives32:
   assert hashlib.sha256(ap.read_bytes()).hexdigest()==sha,(filename,'archive');Archives32[str(ap)]=zipfile.ZipFile(ap)
  raw=Archives32[str(ap)].read(r.get('entry',r.get('member')));digest=r.get('sha256',r.get('member_sha256',r.get('brep_sha256')));assert hashlib.sha256(raw).hexdigest()==digest,(filename,n)
  s=Part.Shape();s.importBrepFromString(raw.decode());Current32[n]=s;Source32[n]={'manifest':filename,'manifest_sha256':LoadPins32[filename],'archive':ap.name,'archive_sha256':sha,'entry':r.get('entry',r.get('member')),'brep_sha256':digest}
for filename in [
'day31-astra-shared-closure-current59-composition.json',
'day31-astra-serial-upper-c1-complete-rigid-source-frame.json',
'day31-astra-common-open-source-bed-c0-complete.json',
'day31-astra-common-open-source-c1-Pfront-curved-complete.json',
'day31-astra-western-return-c0-common-print.json',
'day31-astra-western-return-c1-W044-full-latch-bearing.json',
'day31-astra-common-frame-FLP-full4-source-bed.json',
'day31-astra-lower-south-FLP-c0-complete17.json',
'day31-astra-current-full-W041-factory-port-preflight.json',
'day31-astra-current-both-factory-full-stock-prefixes.json',
'day31-astra-whole-factory-open-bearing-c1-functional-reservations.json',
'day31-astra-common-F0-carrier-loadpath-c0.json',
'day31-astra-common-F0-carrier-c1-full-body-closures.json',
'day31-astra-rear-G2-shared-source-c0-functional.json',
'day31-astra-rear-G2-shared-source-c1-two-level-return.json',
'day31-astra-W026-complete-foot-carrier-c0-functional.json',
'day31-astra-W026-complete-foot-carrier-c1-shared-mounts.json']:
 load_current32(filename)
print('CURRENT_COMPOSITION_IMPORTED',len(Current32),'expected',len(Wanted32),'missing',sorted(Wanted32-set(Current32)),'seconds',time.perf_counter()-tick,'CPU',time.process_time()-cpu,flush=True)
print('CURRENT_DATUMS',{n:saved_bounds(Current32[n]) for n in ['Underdeck:PositiveFoundation','Station:RL_G:case','Ref_Material_W041_Joint_0_0','Carrier:bought:W026:case','Carrier:bought:MTA_FL:case','Station:G2:case'] if n in Current32})

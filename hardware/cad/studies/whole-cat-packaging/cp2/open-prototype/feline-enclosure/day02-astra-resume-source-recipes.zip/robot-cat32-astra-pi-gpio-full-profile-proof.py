tick=time.perf_counter();cpu=time.process_time()
# Full two OD1.4 profiles with0.4edge, centres within segment+-1.8; no axis/R/endpoint change.
p0=start
pv=lambda l,h:v(p0+lat*l+up*h)
profile=Part.Wire([Part.makeLine(pv(-1.8,-1.1),pv(1.8,-1.1)),Part.Arc(pv(1.8,-1.1),pv(2.9,0),pv(1.8,1.1)).toShape(),Part.makeLine(pv(1.8,1.1),pv(-1.8,1.1)),Part.Arc(pv(-1.8,1.1),pv(-2.9,0),pv(-1.8,-1.1)).toShape()])
PiGPIOCapsule32=path.makePipeShell([profile],True,False);PiGPIOCapsule32.check(True);assert PiGPIOCapsule32.isValid() and len(PiGPIOCapsule32.Solids)==1
outside=PiGPIOCapsule32.cut(PiGPIODescent32);outside.check(True);assert outside.isValid();added=outside.Volume
rows=[]
for n in ['Station:Bank:W047/body/end:head_budget','Underdeck:SOURCE:XP03.source']:
 s=CurrentC1Selected32[n];gap=PiGPIOCapsule32.distToShape(s)[0];co=PiGPIOCapsule32.common(s) if gap<1e-7 else None;vol=0
 if co is not None:co.check(True);assert co.isValid();vol=co.Volume
 rows.append({'other':n,'gap_mm':gap,'common_mm3':vol,'hold':gap<1.25-1e-7,'meaning':'Actualhead clearance criterion retained' if 'W047' in n else 'Flexible SOURCE occupied region; overlap is not actual wire contact; full combined occupancy still OPEN'})
arc=OUT/'day02-astra-PiGPIO2-full-profile-capsule.breps.zip';assert not arc.exists();raw=PiGPIOCapsule32.exportBrepToString().encode();g=[{'name':'PiGPIO2:full_two_profile_capsule_same_S','entry':'0.brep','sha256':hashlib.sha256(raw).hexdigest()}]
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as f:f.writestr('0.brep',raw);f.writestr('manifest.json',json.dumps({'geometry':g}))
r={'id':'PI_GPIO2_FULL_PROFILE_SAME_AXIS_SUBSET_PROOF','added_outside_prior_full_rectangle_mm3':added,'full_section':{'segment_mm':3.6,'radius_mm':1.1,'profiles':2,'OD_each_mm':1.4,'edge_each_mm':.4,'endpoint_centre_separation_mm':2*1.27*math.sqrt(2),'axis_R_unchanged_mm':12,'inner_region_R_lower_mm':10.9},'rows':rows,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':g,'reuse':'Only if added<=1e-6, previous positive separation/outline of rectangle remain conservative; no previousHOLD erased','status':'SCOPED_FULL_PROFILE_PROOF_NOT_WHOLE_SELECTION','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-PiGPIO2-full-profile-capsule-proof.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GPIO_FULL_PROFILE',json.dumps(r),flush=True)

tick=time.perf_counter();cpu=time.process_time();rows=[]
for n,m in C1AccessTasks32:
 s=C1Tool32[n];b=Current32[m];gap=s.distToShape(b)[0]
 co=s.common(b) if gap<1e-7 else None;v=co.Volume if co is not None and co.Faces else 0
 rows.append({'tool':n,'other':m,'gap_mm':gap,'common_mm3':v,'contact_material':v>1e-7})
r={'status':'ACTUAL_DRIVER_CONTEXT_REQUIRES_ASSEMBLY_ORDER_DISPOSITION','rows':rows,'scope':'Two full R3x43 straightdrivers at actual W041 screwhead axes. Intersection with own source cap/head must be interpreted by construction; external framework requires feasible preassembly sequence. No whole service claim.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-common-fixture-c1-driver-context.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_DRIVER_CONTEXT',json.dumps(r),flush=True)

tick=time.perf_counter();cpu=time.process_time();import gzip
rows=[];names=[]
for n,s in list(CurrentC1Selected32.items())+[('Pi3:storage_capacity',PiStorage32),('Pi3:transport_capacity',PiTransport32)]:
 b=s.BoundBox
 if b.XMax < -20 or b.XMin>100 or b.YMax < -30 or b.YMin>100 or b.ZMax<70 or b.ZMin>112:continue
 vs,ts=s.tessellate(0.65);arr=[list(v) for v in vs]
 inside=[-20<=v[0]<=100 and -30<=v[1]<=100 and 70<=v[2]<=112 for v in arr]
 tri=[list(t) for t in ts if all(inside[i] for i in t)]
 if not tri:continue
 role='capacity' if n.startswith('Pi3:') else 'north_HOLD' if n.startswith('CurrentNorth:') else 'context'
 rows.append({'name':n,'vertices':arr,'triangles':tri,'role':role,'color':{'capacity':[60,170,155],'north_HOLD':[220,105,55],'context':[166,172,182]}[role]});names.append(n)
p=OUT/'day02-astra-upper-current-regions-view.jsonl.gz';assert not p.exists()
with gzip.open(p,'wt',encoding='utf-8') as f:
 for r in rows:f.write(json.dumps(r,separators=(',',':'))+'\n')
r={'id':'CURRENT_UPPER_REGIONS_CONTEXT_VIEW','mesh':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'names':names,'crop':[[-20,-30,70],[100,100,112]],'scope':'Current1292 fixed/currentcontext plus two unselected Pi3capacity regions. Display crop only, not collision/selection. U1freeprefix shapes outsidecurrentcontext are not drawn; source12currentledger remains separate.','N01_complete':False,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu}
(OUT/'day02-astra-upper-current-regions-view-receipt.json').write_bytes((json.dumps(r,indent=2)+'\n').encode());print('UPPER_VIEW',len(rows),r['operation_seconds'],r['process_cpu_seconds'],flush=True)

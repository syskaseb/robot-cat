tick=time.perf_counter();cpu=time.process_time()
C1Changed32={**C1Parts32,**{k:v for k,v in C1Pressure32.items() if k!='fixed_bearing_material'}}
p=OUT/'day02-astra-common-fixture-c1-pressure-and-frame.breps.zip';assert not p.exists();geo=[]
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for i,(n,s) in enumerate(C1Changed32.items()):
  raw=s.exportBrepToString().encode('utf-8');entry=str(i)+'.brep';z.writestr(entry,raw);geo.append({'name':n,'entry':entry,'sha256':hashlib.sha256(raw).hexdigest(),'role':'C1_functional_same_allocation_NOT_SELECTED'})
 z.writestr('manifest.json',(json.dumps({'geometry':geo},indent=2)+'\n').encode('utf-8'))
manifest={'archive':p.name,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'geometry':geo,'N01_complete':False,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu}
q=OUT/'day02-astra-common-fixture-c1-pressure-and-frame.json';assert not q.exists();q.write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'))
# Existing receipts are scope-specific; these are only new full-context pairs.
prior={(r['part'],r['other']) for r in C1LocalRows32}
joint={('far_back_leg','SourceRoot:W041:custom9:link'),('top_header','Underdeck:PositiveFoundation'),('front_fixed_grip_strap','Upper:W041_side_bearing_reservation')}
retired={'W041Carrier:far_upper_post','Station:RL_G:common_channelled_cap_exterior'}
C1ContextTasks32=[]
for n,s in C1Changed32.items():
 for m,b in Current32.items():
  if m in retired or (n,m) in prior or (n,m) in joint:continue
  if bbox_lower_bound(s.BoundBox,b.BoundBox)<1.25-1e-7:C1ContextTasks32.append((n,m))
C1ContextCursor32=0;C1ContextRows32=[]
def c1_context_chunk32(seconds=15):
 global C1ContextCursor32
 t=time.perf_counter();c=time.process_time();start=C1ContextCursor32;rows=[]
 while C1ContextCursor32<len(C1ContextTasks32) and time.perf_counter()-t<seconds:
  n,m=C1ContextTasks32[C1ContextCursor32];s=C1Changed32[n];b=Current32[m]
  try:
   gap=s.distToShape(b)[0];co=s.common(b) if gap<1e-7 else None
   if co is not None:co.check(True)
   vol=co.Volume if co is not None and co.Faces else 0
   row={'part':n,'other':m,'gap_mm':gap,'common_mm3':vol,'classification':'RAW_INTERFACE_REQUIRES_FUNCTION_DISPOSITION' if gap<1.25-1e-7 else 'SEPARATED_FOREIGN125'}
  except Exception as e:row={'part':n,'other':m,'classification':'ERROR_NOT_CONTACT','error':str(e)}
  rows.append(row);C1ContextRows32.append(row);C1ContextCursor32+=1
 r={'cursor_start':start,'cursor':C1ContextCursor32,'total':len(C1ContextTasks32),'rows':rows,'operation_seconds':time.perf_counter()-t,'process_cpu_seconds':time.process_time()-c,'N01_complete':False}
 p=OUT/('day02-astra-common-fixture-c1-context-'+str(start)+'-'+str(C1ContextCursor32)+'.json');assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_CONTEXT',json.dumps(r),flush=True)
print('C1_CONTEXT_READY',len(C1ContextTasks32),manifest['archive_sha256'],flush=True)

tick=time.perf_counter();cpu=time.process_time()
def extrema32(poly,a,b,minimum=False):
 pts=[a,b]+[float(z.real) for z in poly.deriv().roots() if abs(z.imag)<1e-9 and a<z.real<b]
 vals=[abs(poly(x)) for x in pts]
 if minimum and any(abs(z.imag)<1e-9 and a<=z.real<=b for z in poly.roots()):return 0.
 return min(vals) if minimum else max(vals)
intervals=[]
for i in range(64):
 a=i/64;b=(i+1)/64
 speed2=dx*dx+extrema32(yy32.deriv(),a,b,True)**2+extrema32(zz32.deriv(),a,b,True)**2
 acc=math.hypot(extrema32(yy32.deriv(2),a,b),extrema32(zz32.deriv(2),a,b))
 intervals.append({'u':[a,b],'speed_squared_lower':speed2,'acceleration_upper':acc,'curvature_upper':acc/speed2+1e-9})
Rlower=1/max(x['curvature_upper'] for x in intervals)
# Straight-X plus transverse derivative gives conservative total length upper; no stock correction from an unbuilt curve.
lengthupper=sum((x['u'][1]-x['u'][0])*math.sqrt(dx*dx+extrema32(yy32.deriv(),*x['u'])**2+extrema32(zz32.deriv(),*x['u'])**2) for x in intervals)
r={'id':'SHARED_GALLERY_ONE_ORDERED_BLACK_INTERIOR_MATH','status':'MATH_ONLY_NOT_BUILT_NOT_CLEARANCE','physical_choice':'Leave red lower ingress and both GPIO S fields unchanged; one complete black freeportion across accountingX55->31 with exact old endpoint positions/tangents, south-side common-gallery lane. Not a scalar offset of rejected S; all4entryfields/sourcebudgets bound this hypothesis.','coefficients_power_u_0to1':[x.coef.tolist() for x in [xx32,yy32,zz32]],'R_lower_bound_mm':Rlower,'required_R_mm':12.4,'R_gate_supported':Rlower>=12.4,'length_upper_mm':lengthupper,'old_replaced_axis_length_mm':24.55793843558799,'new_total_factory_debit_upper_mm':160.6596600169126-24.55793843558799+lengthupper,'intervals':intervals,'bound_basis':'On each closed interval, derivative polynomial extrema via all real derivative roots and endpoints. Curvature<=norm(acceleration)/speed^2; speed2 includes minabs first derivatives. +1e-9 outward curvature allowance. Does not prove clearance or geometry fitting.','whole_proposal':'day02-astra-shared-SOURCE-GPIO-gallery-c0-proposal.json','unreceived':['actual four occupiedprofiles interaction','continuous nativeBezier fullpath/retainedprefix equality','whole changedshape vsrigids/outline','sharedassembly/currentinstalledlength/slack/N01'], 'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-shared-gallery-black-continuity-math.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GALLERY_ONE_MATH',Rlower,lengthupper,r['new_total_factory_debit_upper_mm'],r['operation_seconds'],flush=True)

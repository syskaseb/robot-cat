from pathlib import Path
import ast,json,gzip,time
from PIL import Image,ImageDraw,ImageFont
tick=time.monotonic();root=Path('C:/Users/Sysq/PycharmProjects/robot-cat-mechanical');tmp=Path('C:/Users/Sysq/AppData/Local/Temp');out=root/'hardware/cad/studies/whole-cat-packaging/cp2/open-prototype/feline-enclosure';source=root/'tools/cad/pi4_mount_complete_preview.py'
allrows=[json.loads(x) for x in gzip.open(out/'day02-astra-upper-current-regions-view.jsonl.gz','rt',encoding='utf-8')];panels=[]
for pi,view,proj,depth in [(0,'plan section Z<=96','(x,-y)','v[2]'),(0,'north elevation','(x,-z)','v[1]'),(0,'east elevation','(y,-z)','v[0]')]:
 rows=allrows
 # Plan is a clearly labelled lowerbay sectional view. Preserve side view full crop.
 if view.startswith('plan'):
  rows=[dict(r,triangles=[t for t in r['triangles'] if all(r['vertices'][i][2]<=96 for i in t)]) for r in rows]
  rows=[r for r in rows if r['triangles']]
 tree=ast.parse(source.read_text(encoding='utf-8'));main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
 for node in ast.walk(main):
  if isinstance(node,ast.FunctionDef) and node.name=='project':node.body[-1].value=ast.parse(proj,mode='eval').body
  if isinstance(node,ast.Assign):
   names=[x.id for x in node.targets if isinstance(x,ast.Name)]
   if 'rows' in names:node.value=ast.Name(id='ROWS',ctx=ast.Load())
   if 'color' in names:node.value=ast.parse("tuple(row['color'])",mode='eval').body
   if 'depth' in names:node.value=ast.parse('sum('+depth+' for v in verts)/3',mode='eval').body
   if 'labels' in names:node.value=ast.parse(repr([(25,'CURRENT UPPER CONTEXT / Pi3 regions: '+view),(65,'Orange: North retention outline HOLD; teal: scoped capacity, not installed wires.'),(105,'Grey: actual current fixed hardware. Crop X[-20,100] Y[-30,100] Z[70,112].'),(795,'Transport5.4x2.2 / R13: local separation; source merge and GPIO descent OPEN.'),(835,'Annulus is optional slack capacity; board-end fit-trim source permits external offcut.'),(875,'N01 0/10. Projection not contact proof; source12 freefan not drawn; no whole-layout selection.')]),mode='eval').body
 markers=[('U1 bar',[0,94,90]),('Pi3 trunk',[46,60,90]),('slack bay',[40,31,91]),('JPWM',[5,23,87])]
 code="\nfor label,v in MARKERS:\n x,y=pixel(v);draw.ellipse((x-3,y-3,x+3,y+3),fill='black');draw.text((x+4,y-21),label,font=font,fill='black')\n"
 main.body[-1:-1]=ast.parse(code).body;mod=ast.Module(body=[main],type_ignores=[]);ast.fix_missing_locations(mod)
 ns=dict(json=json,ROWS=rows,MARKERS=markers,OUT=tmp,Image=Image,ImageDraw=ImageDraw,ImageFont=ImageFont);exec(compile(mod,str(source),'exec'),ns);ns['main']();panels.append(Image.open(tmp/'preview.png').copy())
result=Image.new('RGB',(1300,930*3),'white')
for i,p in enumerate(panels):result.paste(p,(0,930*i))
target=out/'day02-astra-upper-current-regions-HOLD.png';assert not target.exists();result.save(target);print(target,'render_wall',time.monotonic()-tick)

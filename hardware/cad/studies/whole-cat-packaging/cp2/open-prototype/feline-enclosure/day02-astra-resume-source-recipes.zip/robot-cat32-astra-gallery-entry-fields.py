tick=time.perf_counter();cpu=time.process_time()
inputs={'XP02.source':CurrentC1Selected32['Underdeck:SOURCE:XP02.source'],'XP03.source':CurrentC1Selected32['Underdeck:SOURCE:XP03.source'],'XL07':parts['XL07'],'XL10':parts['XL10']}
rows=[];manifest=[];arc=OUT/'day02-astra-shared-gallery-four-entry-fields.breps.zip';assert not arc.exists()
with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as f:
 for n,s in inputs.items():
  clipped=s.common(SharedSourceGPIO32);clipped.check(True);assert clipped.isValid() and clipped.Solids
  raw=clipped.exportBrepToString().encode();entry=str(len(manifest))+'.brep';f.writestr(entry,raw);manifest.append({'name':n+':prior_occupied_field_inside_common_gallery','entry':entry,'sha256':hashlib.sha256(raw).hexdigest()})
  ports=[]
  for face in clipped.Faces:
   if type(face.Surface).__name__!='Plane':continue
   b=face.BoundBox
   for axis,lo,hi in [('X',31,55),('Y',4,14),('Z',80,90)]:
    mn=getattr(b,axis+'Min');mx=getattr(b,axis+'Max')
    for side,val in [('low',lo),('high',hi)]:
     if abs(mn-val)<1e-6 and abs(mx-val)<1e-6:ports.append({'boundary':axis+':'+side,'coordinate_mm':val,'area_mm2':face.Area,'centroid_mm':list(face.CenterOfMass),'bounds_mm':saved_bounds(face),'normal':list(face.normalAt(0,0))})
  rows.append({'physical_member':n,'source_field_kind':'OD3.1 capacity' if n=='XP02.source' else 'OD1.85 fullSOURCE' if n=='XP03.source' else 'OD1.4 plus0.4 fullcapacity','entry_exit_fields':ports,'inside_volume_mm3':clipped.Volume,'solids':len(clipped.Solids)})
 f.writestr('manifest.json',json.dumps({'geometry':manifest}))
r={'id':'SHARED_GALLERY_FOUR_CURRENT_ENTRY_EXIT_FIELDS','status':'BOUNDARY_FIELDS_RECEIVED_INTERIOR_REWEAVE_R_AND_BALANCE_OPEN','rows':rows,'archive':arc.name,'archive_sha256':hashlib.sha256(arc.read_bytes()).hexdigest(),'geometry':manifest,'meaning':'Exact boundary occupancy of old rejected crossing allocation; preserve physicalidentities and full profile portions. Not chosen interior routes. Planar field normal is boundary normal, not automatically wire tangent. No crossing waived.','required_next':'One common ordered/layered4member assignment matching these fields and protected prefixes with SOURCE R>=12.4/GPIO>=10 plus factory/30slack. Crosssection9.15x3.9 alone not sufficient. No scalarSoffset.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
p=OUT/'day02-astra-shared-gallery-four-entry-fields.json';assert not p.exists();p.write_bytes((json.dumps(r,indent=2)+'\n').encode());print('GALLERY_FIELDS',json.dumps(r),flush=True)

_tick=time.perf_counter();_cpu=time.process_time()
src=Path('C:/Users/Sysq/AppData/Local/Temp/robot-cat29-resume-n01.py').read_text(encoding='utf-8');exec(compile(src[:src.index('fam=json.loads')],'named day26 base import only','exec'))
# Current56 import only; strict16 was already received and is not repeated.
src=Path('C:/Users/Sysq/AppData/Local/Temp/robot-cat31-astra-restore56-strict16.py').read_text(encoding='utf-8');src=src[:src.index('assert len(Current56)')];a=src.index(" if row.get('post_operation_serialization_strict_reopen_pending'):");b=src.index('for z in archives.values():z.close()',a);src=src[:a]+src[b:];exec(compile(src,'current56 bytes only','exec'))
src=Path('C:/Users/Sysq/AppData/Local/Temp/robot-cat31-astra-restore-named-context.py').read_text(encoding='utf-8');src=src[:src.index("r={'status':'NAMED_CURRENT_CONTEXT")];exec(compile(src,'current named source composition only','exec'))
print('RESTORED_NAMED_BASE',os.getpid(),len(G3IntegrationWorld31),len(restMotion),len(Current56),datum,time.perf_counter()-_tick,time.process_time()-_cpu,flush=True)

import sys,os,time,json,hashlib,zipfile,math,itertools,io
from pathlib import Path
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools/cad'))
import FreeCAD as A
import Part
import numpy as np
from receive_feline_global_case_candidates import placement
from feline_solid_distance import bbox_lower_bound,distance
from plan_feline_layout import transforms as leg_transforms
import plan_feline_underframe_jacket_retention as retention
OUT=ROOT/'hardware/cad/studies/whole-cat-packaging/cp2/open-prototype/feline-enclosure'
start29=time.monotonic();CP=json.loads((OUT/'day26-current-shared-mount-and-space.json').read_text());native=OUT/CP['native']['path'];assert hashlib.sha256(native.read_bytes()).hexdigest()==CP['native']['sha256']
material={};restMotion={};newshapes={};metadata={}
doc=A.openDocument(str(native));assert len(doc.Objects)==1180
for obj in doc.Objects:
    if hasattr(obj,'SourceActor'):
        n=obj.SourceActor;material[n]=obj.Shape.copy();metadata[n]={'kind':'current_native_rigid_reference_or_material','source_object':obj.Name}
    elif obj.Name.startswith('NeutralLeg'):
        n=obj.Label.removesuffix(' / neutral reference');restMotion[n]=obj.Shape.copy()
assert len(restMotion)==108
datum=doc.getObject('StudyStatus').RetainedMAINPlatformDatumMm;assert datum==46.52
A.closeDocument(doc.Name)
with zipfile.ZipFile(OUT/CP['geometry_archive']['path']) as z:
    assert hashlib.sha256((OUT/CP['geometry_archive']['path']).read_bytes()).hexdigest()==CP['geometry_archive']['sha256']
    for n,r in CP['geometry'].items():
        raw=z.read(r['member']);assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=Part.Shape();s.importBrepFromString(raw.decode());newshapes[n]=s
stock=json.loads((OUT/'day26-current-installed-tie-envelopes.json').read_text());spec=stock['archive'];print('STOCK_SCHEMA',type(spec),list(spec) if isinstance(spec,dict) else spec,flush=True)
StockStrictConstraints={}
stockpath=OUT/spec['path']
assert hashlib.sha256(stockpath.read_bytes()).hexdigest()==spec['sha256']
with zipfile.ZipFile(stockpath) as z:
    for n,r in stock['geometry'].items():
        raw=z.read(r['member']);assert hashlib.sha256(raw).hexdigest()==r['sha256'];s=Part.Shape();s.importBrepFromString(raw.decode());StockStrictConstraints[n]=s
occupied=dict(material)
# The current native owns applied geometry. Archive names also expose individual
# new shapes, but do not add duplicate frame/carrier/overlapping material copies.
for n,s in StockStrictConstraints.items():occupied[n]=s;metadata[n]={'kind':'installed_stock_planning_envelope','not_exact_supplier_material':True}
fam=json.loads((OUT.parent/'body-harness-checkpoint/leg-source-near-member-plan.json').read_text())
motion=json.loads((OUT/'motion-layout.json').read_text())
axes=json.loads((ROOT/'hardware/simulation/p0/e6-leg-compatibility.json').read_text())['axes']
sourceTriage=json.loads((OUT/'day26-shared-joint-source-triage.json').read_text())['legs']
leg='RL';sourceRows=[r for r in fam['routes'] if r['loom'].startswith(leg)];assert len(sourceRows)==3
code=sourceRows[0]['source']['cad_code'];aa=[next(a for a in axes if a['code']==code and a['stage']==stage) for stage in ['Hip','Knee','Ankle']]
print('ONE_LEG_SOURCE_FIELDS',list(sourceRows[0]['source']),flush=True)
print('LEG_AXES',aa,flush=True)

resume29=dict(status='same_current_sources_recovered',source_native_sha256=CP['native']['sha256'],restore_seconds=time.monotonic()-start29,source_actors=len(material),neutral_parts=len(restMotion),stock_components=len(StockStrictConstraints))
FixtureValidation=json.loads((OUT/'day29-source-fixture-validation.json').read_text())
assert hashlib.sha256((OUT/'RL29SourceFixtures.FCStd').read_bytes()).hexdigest()==FixtureValidation['native_sha256']
Fixture29=A.openDocument(str(OUT/'RL29SourceFixtures.FCStd'))
RL29Outputs={r['part']:Fixture29.getObject(r['native_object']) for r in FixtureValidation['rows']}
assert all(abs(o.Shape.Volume-next(r['volume_mm3'] for r in FixtureValidation['rows'] if r['part']==k))<1e-6 for k,o in RL29Outputs.items())
p29=Fixture29.getObject('RL29Parameters');assert p29.RodRadius.Value==3.
actorsMotion=[]
for idx,pose in enumerate(motion['poses'][:36]):
 for legcode,members in motion['membership'].items():
  legaxes=[next(a for a in axes if a['code']==legcode and a['stage']==stage) for stage in ['Hip','Knee','Ankle']]
  tf=leg_transforms(legaxes,pose['legs'][legcode]['angles_delta_degrees'])
  for oi,stage in enumerate(['Hip','Knee','Ankle']):
   r,t=tf[oi]
   for n in members[stage]:
    s=restMotion[n].copy();s.Placement=placement(r,t)*s.Placement;b=s.BoundBox
    actorsMotion.append(dict(pose=idx,code=legcode,stage=stage,name=n,r=r,t=t,bounds=[[b.XMin,b.YMin,b.ZMin],[b.XMax,b.YMax,b.ZMax]]))
FixedRigidBoxes={n:s.BoundBox for n,s in occupied.items()}
badrest={n for n,s in restMotion.items() if not s.isValid()}
InvalidCovers={}
for n in badrest:
 s=restMotion[n];vv=np.array([list(v.Point) for v in s.Vertexes]);_,ev=np.linalg.eigh(np.cov(vv.T));ev=ev[:,::-1]
 if np.linalg.det(ev)<0:ev[:,2]*=-1
 local=retention.isolated(s);local.Placement=placement(ev.T,[0,0,0])*local.Placement;b=local.BoundBox
 cover=Part.makeBox(b.XLength+.02,b.YLength+.02,b.ZLength+.02,A.Vector(b.XMin-.01,b.YMin-.01,b.ZMin-.01));cover.Placement=placement(ev,[0,0,0])*cover.Placement;cover.check(True);InvalidCovers[n]=cover
old=json.loads((OUT/'day29-source-fork-external-partial.json').read_text())
init=Path(os.environ['TEMP'],'robot-cat29-fork-external.py').read_text();init=init[:init.index("print('FIXTURE_INITIALIZED'")]
exec(init)
assert len(FixtureTasks)==old['tasks']==594,(len(FixtureTasks),old['tasks'])
FixtureCursor=old['checked'];FixtureRows=old['rows'];FixtureReceipt=old
FixtureReceipt['resumed_current_native_sha256']=FixtureValidation['native_sha256']
FixtureReceipt['source_restore']=resume29
print('N01_RESUME_READY',resume29,'motionparts',len(actorsMotion),'cursor',FixtureCursor,'/',len(FixtureTasks),'bad_sources',sorted(badrest),flush=True)

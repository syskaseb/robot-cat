ROOT=Path('C:/Users/Sysq/PycharmProjects/robot-cat-mechanical');OUT=ROOT/'hardware/cad/studies/whole-cat-packaging/cp2/open-prototype/feline-enclosure'
tick=time.perf_counter();cpu=time.process_time()
p=OUT/'day31-astra-carrier-current-selection-stop-limit.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='bcf2c3267ce142fe403bcf4d81748b3c712c8defba1a3393d11f581616c20792'
Selection31=json.loads(p.read_text(encoding='utf-8'));Current56={};DeferredRows31=[];archives={}
for row in Selection31['parts']:
 arc=OUT/row['archive']
 if row['archive'] not in archives:
  assert hashlib.sha256(arc.read_bytes()).hexdigest()==row['archive_sha256'];archives[row['archive']]=zipfile.ZipFile(arc)
 raw=archives[row['archive']].read(row['entry']);assert hashlib.sha256(raw).hexdigest()==row['brep_sha256']
 s=Part.Shape();s.importBrepFromString(raw.decode('utf-8'));Current56[row['current_role']]=s
 if row.get('post_operation_serialization_strict_reopen_pending'):
  err=None
  try:s.check(True);valid=s.isValid() and len(s.Solids)==1
  except Exception as ex:valid=False;err=str(ex)
  DeferredRows31.append({'role':row['current_role'],'source_brep_sha256':row['brep_sha256'],'strict_valid_one_solid':valid,'error':err})
for z in archives.values():z.close()
assert len(Current56)==56 and len(DeferredRows31)==16
r={'status':'CURRENT56_RESTORED_STRICT16_RECEIVED' if all(x['strict_valid_one_solid'] for x in DeferredRows31) else 'CURRENT56_STRICT16_HOLD','pid':os.getpid(),'session_id':85730,'source_selection':p.name,'source_selection_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'restored_actor_count':56,'strict_rows':DeferredRows31,'other40_checks_reused':True,'collision_tests_repeated':0,'operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
f=OUT/'day31-astra-resumed56-strict16-receipt.json';assert not f.exists();f.write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print('RESTORE56_STRICT16',r['status'],r['operation_seconds'],r['process_cpu_seconds'],[x for x in DeferredRows31 if not x['strict_valid_one_solid']],flush=True)

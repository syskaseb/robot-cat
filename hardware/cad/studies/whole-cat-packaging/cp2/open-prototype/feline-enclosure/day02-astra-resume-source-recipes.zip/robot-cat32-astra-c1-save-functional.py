tick=time.perf_counter();cpu=time.process_time();rows=[]
p=OUT/'day02-astra-common-fixture-c1-functional-material.breps.zip';assert not p.exists()
with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:
 for i,(n,s) in enumerate({**C1Parts32,**C1Functional32,**C1Tool32}.items()):
  raw=s.exportBrepToString().encode('utf-8');entry=str(i)+'.brep';z.writestr(entry,raw)
  rows.append({'name':n,'entry':entry,'sha256':hashlib.sha256(raw).hexdigest(),'role':'C1_same_pose_functional_proof_NOT_SELECTED','valid':s.isValid(),'solids':len(s.Solids)})
 z.writestr('manifest.json',(json.dumps({'geometry':rows,'N01_complete':False},indent=2)+'\n').encode('utf-8'))
r={'archive':p.name,'archive_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'geometry':rows,'status':'MATERIAL_CONTINUITY_RECEIVED_PRESSURE_ACCESS_PENDING','pressure_fact':'Existing exact channels leave radial0.15 clearance to all four actual OD3.1 jackets. Two halves split on Y65.6 therefore do not by themselves prove pressure/strain relief; no implicit compression acceptance. Need source-defined closure travel/contact plan without reducing jacket profile.','operation_seconds':time.perf_counter()-tick,'process_cpu_seconds':time.process_time()-cpu,'N01_complete':False}
q=OUT/'day02-astra-common-fixture-c1-functional-material-manifest.json';assert not q.exists();q.write_bytes((json.dumps(r,indent=2)+'\n').encode('utf-8'));print('C1_SAVED',p.name,r['archive_sha256'],len(rows),r['operation_seconds'],flush=True)

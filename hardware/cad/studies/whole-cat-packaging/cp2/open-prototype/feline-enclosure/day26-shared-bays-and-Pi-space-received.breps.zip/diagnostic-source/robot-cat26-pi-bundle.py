import time,math,json
from feline_solid_distance import bbox_lower_bound
if 'pi_bundle_trial26' not in globals():
 R=20.;z=101.6;ym=(46.618109634713775+50.118109634713775)/2
 pairparts26=[tr.line((-16,3,88.5),(-16,12,88.5)),tr.arc((-16,12,88.5),(0,1,0),(4,32,88.5)),tr.line((4,32,88.5),(31,32,88.5)),*tr.biarc((31,32,88.5),(1,0,0),(70,ym+40,z),(1,0,0)),tr.line((70,ym+40,z),(74.7,ym+40,z)),dict(kind='arc',start=[74.7,ym+40,z],end=[74.7,ym,z],tangent=[1,0,0],bend=[0,-1,0],radius=R,angle=math.pi,length=math.pi*R,end_tangent=[-1,0,0])]
 envelope_radius26=3.7
 assert tr.min_radius(pairparts26)-envelope_radius26>=15.9-1e-7
 pair_edges26=[]
 for seg in pairparts26:
  pts=list(tr.samples(seg,max(seg['length']/2,.01)))
  edge=Part.makeLine(A.Vector(*seg['start']),A.Vector(*seg['end'])) if seg['kind']=='line' else Part.Arc(A.Vector(*pts[0]),A.Vector(*pts[len(pts)//2]),A.Vector(*pts[-1])).toShape()
  edge.check(True);pair_edges26.append(edge)
 pi_bundle_trial26={'id':'LOW_PI_PAIR_SHARED_ENVELOPE_NOT_INDIVIDUAL_WIRES','parts':pairparts26,'common_envelope_radius_mm':3.7,'two_selected_wire_capacity_radii_mm':[1.55,1.55],'centre_offsets_mm':[-1.75,1.75],'extra_envelope_allowance_mm':.4,'length_from_central_shaft_to_PAS_mm':tr.length(pairparts26),'centreline_R_min_mm':tr.min_radius(pairparts26),'conservative_inner_boundary_R_min_mm':tr.min_radius(pairparts26)-3.7,'named_hazard':'Under inverted Pi occupiedCPU/DSI/boot and rising to existingPAS; rectangular-space connectivity alone does not prove turns fit.','rows':[],'holds':[],'cursor':0,'pair_cursor':0,'done':[],'seconds':0,'selected':False,'N01_complete':False,'actual_wire_collision_from_negative_bound':False,'PAS_handoff_note':'Common allocation meets existing pairPASfreecaps; overlaps with PAS body/strap are logged as target-interface HOLD, not whole-route clearance or automatic actual conductor collision.'}
 pair_fixed26=list(retainedB26.items());pair_fixed_bounds26={n:s.BoundBox for n,s in pair_fixed26};pair_strict26={}
tickpair26=time.monotonic()
while pi_bundle_trial26['cursor']<len(pair_edges26):
 idx=pi_bundle_trial26['cursor'];edge=pair_edges26[idx];seg=pairparts26[idx]
 while pi_bundle_trial26['pair_cursor']<len(pair_fixed26):
  if time.monotonic()-tickpair26>18:break
  n,s=pair_fixed26[pi_bundle_trial26['pair_cursor']];pi_bundle_trial26['pair_cursor']+=1
  if n=='USB500:full_axis' or n.startswith(('FLArcCuff:','VerticalCuff:','RRDirectGround:','RepackedMiddle:','AuxEscape:')):continue
  if bbox_lower_bound(edge.BoundBox,pair_fixed_bounds26[n])>=3.7+1.25:continue
  try:
   if n not in pair_strict26:
    if n!='CurrentFoundation:BankBedCurrent:-1':s.check(True)
    assert s.Solids,'Occupied reference has no solid';pair_strict26[n]=True
   samples=[A.Vector(*seg['start']),A.Vector(*list(tr.samples(seg,max(seg['length']/2,.01)))[1]),A.Vector(*seg['end'])]
   centre_distance=min(0. if any(so.isInside(p,1e-7,True) for p in samples) else float(edge.distToShape(so)[0]) for so in s.Solids)
   lower=centre_distance-3.7
   pi_bundle_trial26['rows'].append({'span':idx,'occupied':n,'axis_to_source_mm':centre_distance,'whole_bundle_gap_lower_mm':lower,'clear_1_25':lower>=1.25-1e-7,'negative_bound_is_HOLD_not_actual_wire_collision':lower<0,'target_own_handoff':n.startswith('PAS:') and idx==len(pair_edges26)-1})
  except Exception as e:pi_bundle_trial26['holds'].append({'span':idx,'occupied':n,'error':str(e).splitlines()[0] if str(e) else type(e).__name__})
 else:
  pi_bundle_trial26['done'].append(idx);pi_bundle_trial26['cursor']+=1;pi_bundle_trial26['pair_cursor']=0;continue
 break
pi_bundle_trial26['seconds']+=time.monotonic()-tickpair26
packet['day26_current_shared_space_plan']['pi_common_bundle_envelope_trial']=pi_bundle_trial26
result_path.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PI_COMMON_PAIR','done',len(pi_bundle_trial26['done']),'of',len(pair_edges26),'seconds',round(pi_bundle_trial26['seconds'],3),'L',round(tr.length(pairparts26),3),'Rinside',round(tr.min_radius(pairparts26)-3.7,3),'LOW',[(r['span'],r['occupied'],round(r['whole_bundle_gap_lower_mm'],3)) for r in pi_bundle_trial26['rows'] if not r['clear_1_25']][:24],'HOLD',pi_bundle_trial26['holds'][:5],flush=True)

"""Changed whole power bay orientation, not a wire-offset search."""
import time,json
from feline_solid_distance import bbox_lower_bound,distance
if 'bayprobe26' not in globals():
 casesB26={};transformsB26={}
 for n,angle,newcentre in [
 ('Station:FR_P:case',180,(-15.625,57,98)),
 ('Station:RR_P:case',180,(-46.875,57,98)),
 ('Station:RR_G:case',-90,(117,-62.5,98))]:
  src=world[n];c=src.BoundBox.Center;q=src.copy();q.rotate(c,A.Vector(0,0,1),angle);q.translate(A.Vector(*newcentre)-c);q.check(True);casesB26[n]=q;transformsB26[n]={'source_centre_mm':list(c),'centre_mm':newcentre,'rotation_Z_degrees':angle}
 n='ForeFHAC:case';q=world[n].copy();q.translate(A.Vector(-8,0,0));q.check(True);casesB26[n]=q;transformsB26[n]={'translation_mm':[-8,0,0]}
 retiredB26=set(n for n in world if n.startswith(('Station:FR_P:','Station:RR_P:','Station:RR_G:','EarlyRR:','ForeFHAC:')) and n not in casesB26)
 retiredB26.update(('MAINassembly','RRGJointRoot','RRGJointCase4905','MAIN9:band','MAIN9:head'))
 retainedB26={n:s for n,s in prospective26.items() if n not in retiredB26 and n not in casesB26}
 retainedB26.update(casesB26)
 bayprobe26={'id':'DAY26_OUTWARD_POWER_BAY_COMMON_MOUNTS_B','purpose':'Remove inward-facing4mm2 WAGO exit conflict with Pi adapter by changing whole module orientations and joint front power bay; RR_G moves to separate rear negativeY bay. Existing arbitrary source combs/roots unselected; replace by simple shared bed/ties after whole proposal review.','changed_cases':transformsB26,'existing_MAIN9_macro_translation_mm':[12,24,0],'prior_trial_received_no_repeat':True,'removed_old_parts_prospective_ONLY':sorted(retiredB26),'rows':[],'holds':[],'cursor':0,'pair_cursor':0,'done':[],'seconds':0,'selected':False,'N01_complete':False,'physical_pass':False,'actual_factory_ends_and_9_grips':'Geometry preserved by group transform where used; free spans flexible, new source retention/length and swept motion not yet received.'}
 itemsB26=list(retainedB26.items());namesB26=list(casesB26);boundsB26={n:s.BoundBox for n,s in itemsB26};checkB26={}
 bayprobe26['outline']=gal.constant_torso_section_bounds(casesB26)
tickB26=time.monotonic()
while bayprobe26['cursor']<len(namesB26):
 n=namesB26[bayprobe26['cursor']];q=casesB26[n]
 while bayprobe26['pair_cursor']<len(itemsB26):
  if time.monotonic()-tickB26>18:break
  k,s=itemsB26[bayprobe26['pair_cursor']];bayprobe26['pair_cursor']+=1
  if n==k or k=='USB500:full_axis' or k.startswith(('FLArcCuff:','VerticalCuff:','RRFlat:','RRDirectGround:','RepackedMiddle:')):continue
  if bbox_lower_bound(q.BoundBox,boundsB26[k])>=1.25:continue
  try:
   if k not in checkB26:
    if k!='CurrentFoundation:BankBedCurrent:-1':s.check(True)
    assert s.Solids,'No occupied solid';checkB26[k]=True
   gap=distance(q,s);row={'case':n,'occupied':k,'gap_mm':gap,'ok':gap>=1.25-1e-7}
   if gap<1e-7:
    common=q.common(s)
    if common.Solids:common.check(True)
    row['positive_overlap_mm3']=float(common.Volume)
   bayprobe26['rows'].append(row)
  except Exception as e:bayprobe26['holds'].append({'case':n,'occupied':k,'error':str(e).splitlines()[0] if str(e) else type(e).__name__})
 else:
  bayprobe26['done'].append(n);bayprobe26['cursor']+=1;bayprobe26['pair_cursor']=0;continue
 break
bayprobe26['seconds']+=time.monotonic()-tickB26
packet['day26_current_shared_space_plan']['outward_power_bay_trial']=bayprobe26
result_path.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('POWER_BAY_B','done',len(bayprobe26['done']),'of4','seconds',round(bayprobe26['seconds'],3),'LOW',[(r['case'],r['occupied'],round(r['gap_mm'],3),round(r.get('positive_overlap_mm3',0),3)) for r in bayprobe26['rows'] if not r['ok']],'HOLD',bayprobe26['holds'][:6],flush=True)

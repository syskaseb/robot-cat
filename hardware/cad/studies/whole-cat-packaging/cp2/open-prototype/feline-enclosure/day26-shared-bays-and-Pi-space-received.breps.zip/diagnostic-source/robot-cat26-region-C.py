import json,time
from feline_solid_distance import bbox_lower_bound,distance
if 'regiontrialC26' not in globals():
 b2={
 'UPPER_NEG_19':((-120,-94,99),(145,-75,106)),
 'UPPER_POS_19':((-120,75,99),(145,94,106)),
 'PI_UNDER_TRANSFER_LOW':((-22,3,85),(45.25,30,92)),
 'PI_UNDER_NORTH_LOW':((31,30,85),(45.25,58,92)),
 'PI_NORTH_RISER_LOW':((31,57,85),(45.25,78,106)),
 'PI_TOP_RETURN_LOW':((31,57,99),(94,78,106)),
 'PI_RECEIVER_LOW':((49,40,99),(94,78,106))}
 regionsC26={n:Part.makeBox(*(hi[i]-lo[i] for i in range(3)),A.Vector(*lo)) for n,(lo,hi) in b2.items()}
 regiontrialC26={'id':'DAY26_LOW_PI_AND_SHARED19_SPACE_C_PRECHECK','bounds_mm':b2,'rows':[],'holds':[],'done':[],'cursor':0,'pair_cursor':0,'seconds':0,'N01_complete':False,'not_empty_space_acceptance_from_projection':True}
 namesRC26=list(regionsC26)
 regiontrialC26['outline']=gal.constant_torso_section_bounds(regionsC26)
tickRC26=time.monotonic()
while regiontrialC26['cursor']<len(namesRC26):
 n=namesRC26[regiontrialC26['cursor']];q=regionsC26[n]
 while regiontrialC26['pair_cursor']<len(itemsB26):
  if time.monotonic()-tickRC26>18:break
  k,s=itemsB26[regiontrialC26['pair_cursor']];regiontrialC26['pair_cursor']+=1
  if k=='USB500:full_axis' or k.startswith(('FLArcCuff:','VerticalCuff:','RRFlat:','RRDirectGround:','RepackedMiddle:','AuxEscape:')):continue
  if bbox_lower_bound(q.BoundBox,boundsB26[k])>=1.25:continue
  try:
   if k not in checkB26:
    if k!='CurrentFoundation:BankBedCurrent:-1':s.check(True)
    assert s.Solids,'No occupied solid';checkB26[k]=True
   gap=distance(q,s);row={'region':n,'occupied':k,'gap_mm':gap,'ok':gap>=1.25-1e-7}
   if gap<1e-7:
    common=q.common(s)
    if common.Solids:common.check(True)
    row['positive_overlap_mm3']=float(common.Volume)
   regiontrialC26['rows'].append(row)
  except Exception as e:regiontrialC26['holds'].append({'region':n,'occupied':k,'error':str(e).splitlines()[0] if str(e) else type(e).__name__})
 else:
  regiontrialC26['done'].append(n);regiontrialC26['cursor']+=1;regiontrialC26['pair_cursor']=0;continue
 break
regiontrialC26['seconds']+=time.monotonic()-tickRC26
packet['day26_current_shared_space_plan']['region_C_precheck']=regiontrialC26
result_path.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('REGION_C','done',len(regiontrialC26['done']),'of7','seconds',round(regiontrialC26['seconds'],3),'LOW',[(r['region'],r['occupied'],round(r['gap_mm'],3),round(r.get('positive_overlap_mm3',0),3)) for r in regiontrialC26['rows'] if not r['ok']],'HOLD',regiontrialC26['holds'][:5],flush=True)
